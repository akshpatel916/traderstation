import { useState, useEffect } from "react";
import { QuoteData, CalendarEvent, NewsItem } from "../types";
import { clsx } from "clsx";

interface DataOverviewProps {
  category: string;
  onOpenChart: (symbol: string) => void;
}

const CATEGORY_SYMBOLS: Record<string, string[]> = {
  "Markets": ["^GSPC", "^DJI", "^IXIC", "^NSEI", "^BSESN", "^VIX", "^FTSE", "^N225", "NVDA", "AAPL", "MSFT"],
  "India": ["^NSEI", "^BSESN", "RELIANCE.NS", "RELIANCE.BO", "TCS.NS", "TCS.BO", "HDFCBANK.NS", "HDFCBANK.BO", "INFY.NS", "INFY.BO", "ICICIBANK.NS", "ICICIBANK.BO", "SBIN.NS", "SBIN.BO", "ITC.NS", "ITC.BO", "HINDUNILVR.NS", "IOC.NS", "LT.NS", "ASIANPAINT.NS"],
  "ETFs": ["SPY", "QQQ", "IWM", "EFA", "ARKK", "VTI", "VOO", "VEA", "VWO", "XLK", "XLF", "XLV", "XLE", "SMH", "VNQ", "GLD", "SLV", "NIFTYBEES.NS"],
  "Forex": ["EURUSD=X", "JPY=X", "GBPUSD=X", "AUDUSD=X", "USDCHF=X", "USDCAD=X", "NZDUSD=X", "EURGBP=X", "EURJPY=X", "GBPJPY=X", "USDINR=X", "EURINR=X", "GBPINR=X"],
  "Crypto": ["BTC-USD", "ETH-USD", "SOL-USD", "BNB-USD", "XRP-USD", "ADA-USD", "DOGE-USD", "DOT-USD", "MATIC-USD", "LTC-USD", "AVAX-USD", "LINK-USD"],
  "Commodities": ["GC=F", "CL=F", "SI=F", "HG=F", "NG=F", "ZC=F", "ZW=F", "ZS=F", "CC=F", "SB=F", "BZ=F", "HO=F"],
};

export function DataOverview({ category, onOpenChart }: DataOverviewProps) {
  const [data, setData] = useState<QuoteData[]>([]);
  const [loading, setLoading] = useState(false);
  const [news, setNews] = useState<NewsItem[]>([]);
  const [calendar, setCalendar] = useState<CalendarEvent[]>([]);

  useEffect(() => {
    let mounted = true;
    
    // Fetch quotes if applicable
    let symbols = CATEGORY_SYMBOLS[category];
    if (category === "Markets") {
      symbols = [...new Set([
        ...CATEGORY_SYMBOLS["Markets"],
        ...CATEGORY_SYMBOLS["Forex"].slice(0, 6),
        ...CATEGORY_SYMBOLS["Crypto"].slice(0, 6)
      ])];
    }

    if (symbols) {
      setLoading(true);
      fetch(`/api/stocks/quotes?symbols=${encodeURIComponent(symbols.join(','))}`)
        .then(res => res.json())
        .then(resData => {
          if (mounted && Array.isArray(resData)) {
            setData(resData);
          }
        })
        .finally(() => {
          if (mounted) setLoading(false);
        });
    } else {
      setData([]);
    }

    if (category === "News" || category === "Markets") {
      fetch(`/api/news?symbol=SPY`)
        .then(res => res.json())
        .then(resData => {
          if (mounted && Array.isArray(resData)) setNews(resData);
        });
    }

    if (category === "Calendar" || category === "Markets") {
      fetch(`/api/calendar`)
        .then(res => res.json())
        .then(resData => {
          if (mounted && Array.isArray(resData)) setCalendar(resData);
        });
    }

    return () => { mounted = false };
  }, [category]);

  const renderTable = (items: QuoteData[], title: string) => (
    <div className="bg-[#16161a] border border-gray-800 rounded-lg overflow-hidden flex-1 shrink-0 min-w-[300px]">
      <div className="px-4 py-3 border-b border-gray-800 bg-[#16161a]/50 text-xs font-bold text-gray-400 uppercase tracking-widest">
        {title}
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-gray-800/50 bg-[#09090b]/50">
              <th className="px-4 py-2 text-[10px] font-medium text-gray-500 uppercase tracking-widest">Symbol</th>
              <th className="px-4 py-2 text-[10px] font-medium text-gray-500 uppercase tracking-widest text-right">Last Price</th>
              <th className="px-4 py-2 text-[10px] font-medium text-gray-500 uppercase tracking-widest text-right">Change</th>
              <th className="px-4 py-2 text-[10px] font-medium text-gray-500 uppercase tracking-widest text-right">% Chg</th>
              <th className="px-4 py-2 text-[10px] font-medium text-gray-500 uppercase tracking-widest text-right">Volume</th>
            </tr>
          </thead>
          <tbody>
            {items.map(q => {
              const chg = q.regularMarketChange || 0;
              const isUp = chg >= 0;
              return (
                <tr 
                  key={q.symbol} 
                  className="border-b border-gray-800/20 hover:bg-gray-800/40 cursor-pointer transition-colors"
                  onClick={() => onOpenChart(q.symbol)}
                >
                  <td className="px-4 py-2.5">
                    <div className="text-[12px] font-bold text-gray-200">{q.symbol.replace("=X","").replace("-USD","").replace("=F", "")}</div>
                    <div className="text-[10px] text-gray-500 truncate max-w-[150px]">{q.shortName || q.symbol}</div>
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-[12px] text-gray-300">
                    {q.regularMarketPrice?.toFixed(2) || "-"}
                  </td>
                  <td className={clsx("px-4 py-2.5 text-right font-mono text-[12px]", isUp ? "text-emerald-400" : "text-rose-500")}>
                    {isUp ? "+" : ""}{chg.toFixed(2)}
                  </td>
                  <td className={clsx("px-4 py-2.5 text-right font-mono text-[12px] font-bold", isUp ? "text-emerald-400" : "text-rose-500")}>
                    {isUp ? "+" : ""}{q.regularMarketChangePercent?.toFixed(2)}%
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-[12px] text-gray-500">
                    {q.regularMarketVolume ? (q.regularMarketVolume / 1000000).toFixed(2) + 'M' : '-'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  if (category === "Calendar") {
    // Group events by date string (e.g., "Jun 17")
    const groupedCalendar: Record<string, typeof calendar> = {};
    calendar.forEach(event => {
      const dateStr = new Date(event.date).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
      if (!groupedCalendar[dateStr]) groupedCalendar[dateStr] = [];
      groupedCalendar[dateStr].push(event);
    });

    return (
      <div className="p-6 max-w-5xl mx-auto w-full">
        <h1 className="text-2xl font-bold text-white mb-6 uppercase tracking-widest">Economic Calendar</h1>
        <div className="bg-[#16161a] border border-gray-800 rounded-lg overflow-hidden">
          <div className="grid grid-cols-[100px_60px_60px_1fr] bg-[#09090b]/50 px-4 py-2 border-b border-gray-800/50 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
            <div>Time</div>
            <div>Cur</div>
            <div>Imp</div>
            <div>Event</div>
          </div>
          {Object.entries(groupedCalendar).map(([dateStr, eventsForDay]) => (
            <div key={dateStr}>
              <div className="bg-[#111115] px-4 py-2 text-[11px] font-bold text-indigo-400 border-b border-gray-800/50 uppercase tracking-widest sticky top-0">
                {dateStr}
              </div>
              {eventsForDay.map((event, i) => {
                const impactLower = event.impact.toLowerCase();
                const isHigh = impactLower === "high";
                const isMed = impactLower === "medium" || impactLower === "med";
                const isLow = !isHigh && !isMed;

                return (
                 <div key={i} className="grid grid-cols-[100px_60px_60px_1fr] items-center px-4 py-2 border-b border-gray-800/30 hover:bg-gray-800/30 transition-colors">
                  <div className="text-[12px] text-gray-400 font-mono">
                    {new Date(event.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <div className="text-[12px] font-bold text-gray-300 uppercase">{event.country}</div>
                  <div className="flex items-center">
                    <div className={clsx(
                      "w-4 h-4 rounded-sm flex items-center justify-center",
                       isHigh ? "bg-rose-500" : isMed ? "bg-amber-500" : "bg-emerald-500"
                    )}>
                      <div className="w-1 h-1 bg-white/50 rounded-full" />
                    </div>
                  </div>
                  <div className="text-[13px] font-medium text-gray-200 truncate pr-4">{event.title}</div>
                 </div>
                );
              })}
            </div>
          ))}
          {calendar.length === 0 && (
            <div className="p-8 text-center text-gray-500 text-[12px]">Loading events...</div>
          )}
        </div>
      </div>
    );
  }

  const defaultWatchlist = ["AAPL", "TSLA", "NVDA", "RELIANCE.NS", "MSFT"];

  let displayData = data;
  let forexData: QuoteData[] = [];
  let cryptoData: QuoteData[] = [];
  let marketsData = data;
  let watchlistData: QuoteData[] = [];

  if (category === "Markets") {
    forexData = data.filter(q => CATEGORY_SYMBOLS["Forex"].includes(q.symbol)).slice(0, 6);
    cryptoData = data.filter(q => CATEGORY_SYMBOLS["Crypto"].includes(q.symbol)).slice(0, 6);
    marketsData = data.filter(q => CATEGORY_SYMBOLS["Markets"].includes(q.symbol));
    watchlistData = data.filter(q => defaultWatchlist.includes(q.symbol));
    displayData = marketsData;
  }

  const sortedData = [...displayData].sort((a,b) => (b.regularMarketChangePercent || 0) - (a.regularMarketChangePercent || 0));
  const gainers = sortedData.filter(q => !q.symbol.startsWith('^')).slice(0, 5);
  const losers = [...sortedData].filter(q => !q.symbol.startsWith('^')).reverse().slice(0, 5);
  // Separate indices from normal tickers
  const indices = displayData.filter(q => q.symbol.startsWith('^'));
  const others = displayData.filter(q => !q.symbol.startsWith('^'));

  return (
    <div className="p-6 max-w-7xl mx-auto w-full flex flex-col gap-6">
      <h1 className="text-2xl font-bold text-white uppercase tracking-widest">{category} Overview</h1>
      
      {loading ? (
        <div className="animate-pulse flex gap-4 h-32">
          <div className="flex-1 bg-[#16161a] rounded"></div>
          <div className="flex-1 bg-[#16161a] rounded"></div>
          <div className="flex-1 bg-[#16161a] rounded"></div>
        </div>
      ) : (
        <>
          {indices.length > 0 && (
             <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
               {indices.map(idx => {
                 const isUp = (idx.regularMarketChange || 0) >= 0;
                 return (
                   <div 
                     key={idx.symbol} 
                     className="bg-[#16161a] border border-gray-800 rounded-lg p-3 cursor-pointer hover:border-gray-600 transition-colors"
                     onClick={() => onOpenChart(idx.symbol)}
                   >
                     <div className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-1">{idx.shortName || idx.symbol}</div>
                     <div className="text-lg font-mono font-bold text-white mb-1">{idx.regularMarketPrice?.toFixed(2)}</div>
                     <div className={clsx("text-[11px] font-mono font-bold flex items-center gap-1", isUp ? "text-emerald-400" : "text-rose-500")}>
                       {isUp ? "▲" : "▼"} {Math.abs(idx.regularMarketChange || 0).toFixed(2)} ({Math.abs(idx.regularMarketChangePercent || 0).toFixed(2)}%)
                     </div>
                   </div>
                 );
               })}
             </div>
          )}

          <div className="flex flex-wrap lg:flex-nowrap gap-6 w-full items-stretch">
            {renderTable(gainers, "Top Gainers")}
            {renderTable(losers, "Top Losers")}
            {category === "Markets" && renderTable(watchlistData, "My Watchlist")}
          </div>

          {category === "Markets" && (
             <div className="flex flex-wrap lg:flex-nowrap gap-6 w-full items-stretch mt-2">
               {renderTable(others.slice(0, 6), "Most Active Equities")}
               {forexData.length > 0 && renderTable(forexData, "Currencies (FX)")}
               {cryptoData.length > 0 && renderTable(cryptoData, "Cryptocurrencies")}
             </div>
          )}

          {others.length > 0 && category !== "Markets" && (
             <div className="w-full">
               {renderTable(others, "Most Active / Key Components")}
             </div>
          )}
        </>
      )}
    </div>
  );
}
