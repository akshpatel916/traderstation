import { useState, useEffect, useRef } from "react";
import { Search, X, TrendingUp, Loader2 } from "lucide-react";
import { clsx } from "clsx";

interface SearchResult {
  symbol: string;
  shortname: string;
  longname: string;
  exchange: string;
  quoteType: string;
}

interface SearchOverlayProps {
  onClose: () => void;
  onSelect: (symbol: string) => void;
}

export function SearchOverlay({ onClose, onSelect }: SearchOverlayProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    const fetchResults = async () => {
      if (query.trim().length < 2) {
        setResults([]);
        return;
      }
      setLoading(true);
      try {
        const res = await fetch(`/api/ism/search?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        if (data.status === "success") {
           setResults(data.results);
        } else {
           setResults([]);
        }
      } catch (err) {
        console.error("Search error", err);
      } finally {
        setLoading(false);
      }
    };
    const timer = setTimeout(() => {
      fetchResults();
    }, 300);
    return () => clearTimeout(timer);
  }, [query]);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-start justify-center pt-24 px-4 overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#16161a] border border-gray-800 rounded-lg shadow-2xl overflow-hidden mb-24">
        <div className="flex items-center gap-3 px-4 py-4 border-b border-gray-800">
          <Search className="w-5 h-5 text-gray-400" />
          <input 
            ref={inputRef}
            type="text"
            className="flex-1 bg-transparent border-none outline-none text-white text-lg placeholder-gray-500 font-medium"
            placeholder="Search stocks, ETFs, indices (e.g. RELIANCE, AAPL)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {loading && <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" />}
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-gray-800 rounded-full text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        {query.length > 0 && results.length === 0 && !loading && (
           <div className="p-8 text-center text-sm text-gray-500">
             No results found for "{query}".
           </div>
        )}

        {results.length > 0 && (
          <div className="max-h-[60vh] overflow-y-auto hide-scrollbar">
            {results.map((r, i) => (
              <div 
                key={`${r.symbol}-${i}`}
                className="px-4 py-3 border-b border-gray-800/50 hover:bg-[#1f1f23] cursor-pointer flex items-center justify-between group transition-colors"
                onClick={() => {
                  onSelect(r.symbol);
                  onClose();
                }}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-gray-200 group-hover:text-indigo-400 transition-colors">{r.symbol}</span>
                    <span className="text-[10px] bg-gray-800 text-gray-400 px-1.5 py-0.5 rounded font-mono uppercase">
                      {r.exchange}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 mt-0.5 truncate max-w-sm">
                    {r.longname || r.shortname || r.symbol}
                  </div>
                </div>
                <div className="text-[10px] text-gray-600 uppercase tracking-widest font-semibold flex items-center gap-1">
                  {r.quoteType} <TrendingUp className="w-3 h-3 group-hover:text-emerald-400 transition-colors" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
