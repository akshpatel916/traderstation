import { Search } from "lucide-react";
import { clsx } from "clsx";
import { auth } from "../firebase";
import { signInWithPopup, GoogleAuthProvider, signOut } from "firebase/auth";
import { useState, useEffect } from "react";

interface NavbarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  onSearchClick: () => void;
}

const TABS = ["Markets", "India", "ETFs", "Forex", "Crypto", "Community", "News", "Calendar"];

export function Navbar({ activeView, onNavigate, onSearchClick }: NavbarProps) {
  const [user, setUser] = useState(auth.currentUser);

  useEffect(() => {
    return auth.onAuthStateChanged(u => setUser(u));
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, new GoogleAuthProvider());
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="bg-[#16161a] border-b border-gray-800 px-4 py-3 flex items-center justify-between z-40 shrink-0">
      <div className="font-bold text-[15px] text-white flex items-center gap-2 cursor-pointer" onClick={() => onNavigate("Markets")}>
        <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center shadow-lg shadow-indigo-500/20 text-[10px] font-black">
          T
        </div>
        Trader Station
      </div>
      <div className="hidden md:flex gap-6 text-[12px] font-medium text-gray-500 uppercase tracking-widest">
        {TABS.map(tab => (
          <span 
            key={tab}
            onClick={() => onNavigate(tab)}
            className={clsx(
              "cursor-pointer hover:text-white transition-colors",
              activeView === tab ? "text-indigo-400" : "text-gray-400"
            )}
          >
            {tab}
          </span>
        ))}
      </div>
      <div className="flex items-center gap-4">
        <Search onClick={onSearchClick} className="w-4 h-4 text-gray-400 cursor-pointer hover:text-white transition-colors" />
        {user ? (
          <div className="flex items-center gap-3">
            <span className="text-[11px] text-gray-400 font-medium hidden sm:block truncate max-w-[100px]">{user.displayName}</span>
            <img src={user.photoURL || `https://ui-avatars.com/api/?name=${user.email || "U"}`} alt="" className="w-6 h-6 rounded-full border border-gray-700" />
            <button onClick={() => signOut(auth)} className="text-[11px] font-medium px-3 py-1.5 border border-gray-700 rounded bg-[#09090b] hover:bg-gray-800 transition-colors text-white uppercase tracking-widest">
              Out
            </button>
          </div>
        ) : (
          <button onClick={handleLogin} className="text-[11px] font-medium px-4 py-1.5 border border-gray-700 rounded bg-[#09090b] hover:bg-gray-800 transition-colors text-white uppercase tracking-widest">
            Log in
          </button>
        )}
      </div>
    </div>
  );
}

