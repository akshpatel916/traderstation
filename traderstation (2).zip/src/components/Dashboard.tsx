import { useState, useEffect } from "react";
import { StockChart } from "./StockChart";
import { DeepAnalytics } from "./DeepAnalytics";
import { QuoteData, CalendarEvent, NewsItem } from "../types";
import { clsx } from "clsx";
import { Settings } from "lucide-react";

type Tab = "Stocks" | "FX" | "Crypto";
type ScreenerTab = "Gainers" | "Losers" | "Active" | "News";
type ViewMode = "Chart" | "Deep Analysis";

function NewsFeed({ symbol }: { symbol: string }) {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let mounted = true;
    const fetchNews = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/news?symbol=${encodeURIComponent(symbol)}`);
        const data = await res.json();
        if (mounted && Array.isArray(data)) {
          setNews(data);
        }
      } catch (err) {
        console.warn("Failed to fetch news", err);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    fetchNews();
    return () => { mounted = false; };
  }, [symbol]);

  if (loading) {
    return <div className="p-4 text-center text-xs text-gray-500 animate-pulse">Loading news...</div>;
  }

  if (news.length === 0) {
    return <div className="p-4 text-center text-xs text-gray-500">No news available</div>;
  }

  return (
    <div className="flex flex-col gap-2 p-2">
      {news.map((item, i) => (
        <a key={item.uuid || i} href={item.link} target="_blank" rel="noopener noreferrer" className="block p-3 rounded hover:bg-gray-800/40 transition-colors border border-gray-800/20">
          <div className="text-[11px] font-bold text-gray-200 line-clamp-2 mb-1">{item.title}</div>
          <div className="flex justify-between items-center text-[9px] text-gray-500">
            <span>{item.publisher}</span>
            <span>{new Date(item.providerPublishTime).toLocaleDateString()}</span>
          </div>
        </a>
      ))}
    </div>
  );
}

function CalendarItemWidget({ event }: { event: CalendarEvent }) {
  const isHigh = event.impact.toLowerCase() === "high";
  const isMed = event.impact.toLowerCase() === "medium" || event.impact.toLowerCase() === "med";
  const timeStr = new Date(event.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="grid grid-cols-[auto_1fr_auto] gap-2 items-center px-3 py-2 border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors">
      <div className="flex flex-col">
          <div className="text-[10px] text-gray-400 font-mono leading-none">{timeStr}</div>
      </div>
      <div className="flex flex-col overflow-hidden pl-2">
          <div className="flex items-center gap-1.5 mb-1">
              <span className="text-[10px] uppercase font-bold text-gray-500 leading-none">{event.country}</span>
              <div className={clsx(
                "w-3 h-3 rounded-sm flex items-center justify-center shrink-0",
                  isHigh ? "bg-rose-500" : isMed ? "bg-amber-500" : "bg-emerald-500"
              )}>
                <div className="w-1 h-1 bg-white/50 rounded-full" />
              </div>
          </div>
          <span className="text-[11px] text-gray-200 truncate leading-tight">{event.title}</span>
      </div>
    </div>
  );
}

export function Dashboard({ initialSymbol = "AAPL" }: { initialSymbol?: string }) {
  const [selectedSymbol, setSelectedSymbol] = useState(initialSymbol);

  useEffect(() => {
    setSelectedSymbol(initialSymbol);
  }, [initialSymbol]);
  const [activeTab, setActiveTab] = useState<Tab>("Stocks");
  const [watchlist, setWatchlist] = useState<QuoteData[]>([]);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [screenerTab, setScreenerTab] = useState<ScreenerTab>("Gainers");
  const [viewMode, setViewMode] = useState<ViewMode>("Chart");

  const [lists, setLists] = useState<Record<Tab, string[]>>({
    Stocks: ["AAPL", "TSLA", "NVDA", "RELIANCE.NS", "TCS.NS", "INFY.NS", "MSFT", "AMZN"],
    FX: ["EURUSD=X", "JPY=X", "GBPUSD=X", "AUDUSD=X", "USDCHF=X"],
    Crypto: ["BTC-USD", "ETH-USD", "SOL-USD", "BNB-USD", "DOGE-USD"],
  });
  const [isAdding, setIsAdding] = useState(false);
  const [newSymbolParams, setNewSymbolParams] = useState("");

  useEffect(() => {
    let mounted = true;
    const fetchWatchlist = async () => {
      try {
        const syms = [...new Set([...lists[activeTab], selectedSymbol])];
        if (!syms || syms.length === 0) {
           setWatchlist([]);
           return;
        }
        const res = await fetch(`/api/ism/stock/list?symbols=${encodeURIComponent(syms.join(','))}&res=num`);
        const data = await res.json();
        if (mounted && data.status === "success" && Array.isArray(data.stocks)) {
           // map back to expected QuoteData structure
           const mappedResults = data.stocks.map((item: any) => ({
             symbol: item.ticker,
             shortName: item.company_name,
             exchange: item.exchange,
             regularMarketPrice: item.last_price,
             regularMarketChange: item.change,
             regularMarketChangePercent: item.percent_change,
             regularMarketPreviousClose: item.previous_close,
             regularMarketOpen: item.open,
             regularMarketDayHigh: item.day_high,
             regularMarketDayLow: item.day_low,
             regularMarketVolume: item.volume,
             marketCap: item.market_cap,
             trailingPE: item.pe_ratio,
             fiftyTwoWeekHigh: item.year_high,
             fiftyTwoWeekLow: item.year_low
           }));
           setWatchlist(mappedResults);
        }
      } catch (e) {
        console.warn("Error fetching watchlist", e);
      }
    };
    
    const fetchCalendar = async () => {
      try {
        const res = await fetch('/api/calendar');
        if (!res.ok) return;
        const data = await res.json();
        if (mounted && Array.isArray(data)) {
          // get upcoming 5 events today/this week
          const now = new Date();
          let upcoming = data.filter((e: CalendarEvent) => new Date(e.date) > now).slice(0, 5);
          if (upcoming.length === 0) {
             upcoming = data.slice(-5); // Use the last 5 events from the week if none are upcoming
          }
          setEvents(upcoming);
        }
      } catch (e) {
        console.warn("Error calendar fetch", e);
      }
    };

    fetchWatchlist();
    fetchCalendar();
    const interval = setInterval(fetchWatchlist, 10000); // refresh every 10s
    return () => { 
      mounted = false;
      clearInterval(interval); 
    };
  }, [activeTab, lists, selectedSymbol]);

  const handleAddSymbol = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSymbolParams.trim()) return;
    const s = newSymbolParams.trim().toUpperCase();
    setLists(prev => ({ ...prev, [activeTab]: [s, ...prev[activeTab]] }));
    setNewSymbolParams("");
    setIsAdding(false);
  };


  const selectedQuote = watchlist.find(q => q.symbol === selectedSymbol) || { symbol: selectedSymbol };
  const activeSymbol = selectedQuote.symbol;

  const sortedScreener = [...watchlist].sort((a, b) => {
    if (screenerTab === "Gainers") return (b.regularMarketChangePercent || 0) - (a.regularMarketChangePercent || 0);
    if (screenerTab === "Losers") return (a.regularMarketChangePercent || 0) - (b.regularMarketChangePercent || 0);
    return (b.regularMarketVolume || 0) - (a.regularMarketVolume || 0);
  });

  return (
    <div className="flex flex-col md:flex-row min-h-full md:h-full box-border">
      {/* Left Column - Watchlist */}
      <div className="w-full md:w-[220px] md:border-r border-b md:border-b-0 border-gray-800 flex flex-col shrink-0 bg-[#09090b] h-[300px] md:h-auto">
        <div className="flex border-b border-gray-800">
          {(["Stocks", "FX", "Crypto"] as Tab[]).map(t => (
             <button 
               key={t}
               onClick={() => setActiveTab(t)}
               className={clsx(
                 "flex-1 py-2.5 text-[10px] font-medium border-b-2 transition-colors uppercase tracking-wider",
                 activeTab === t ? "border-indigo-500 text-white" : "border-transparent text-gray-500 hover:text-gray-300"
               )}
             >{t}</button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto hide-scrollbar py-2">
          <div className="flex items-center justify-between px-3 pb-2 pt-1 border-b border-gray-800/30 mb-1">
            <span className="text-[10px] font-medium text-gray-500 uppercase tracking-widest">Watchlist</span>
            <button onClick={() => setIsAdding(!isAdding)} className="text-gray-400 hover:text-white">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>
            </button>
          </div>
          {isAdding && (
            <form onSubmit={handleAddSymbol} className="px-3 py-2 border-b border-gray-800/30 flex gap-2">
              <input 
                autoFocus
                type="text" 
                value={newSymbolParams}
                onChange={(e) => setNewSymbolParams(e.target.value)}
                placeholder="Add Sym (e.g. AAPL)" 
                className="w-full bg-[#16161a] border border-gray-700 rounded px-2 py-1 text-[11px] text-white focus:outline-none focus:border-indigo-500"
              />
              <button type="submit" className="px-2 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-[10px] font-medium transition-colors">
                 Add
              </button>
            </form>
          )}
          {watchlist.map(q => {
            const isUp = (q.regularMarketChange || 0) >= 0;
            return (
              <div 
                key={q.symbol}
                onClick={() => setSelectedSymbol(q.symbol)}
                className={clsx(
                  "flex justify-between items-center px-3 py-2 cursor-pointer transition-colors",
                  activeSymbol === q.symbol ? "bg-gray-800" : "hover:bg-gray-800/40"
                )}
              >
                <div className="flex flex-col overflow-hidden mr-2">
                  <div className="text-[11px] font-semibold text-gray-200">{q.symbol.replace("=X", "").replace("-USD", "")}</div>
                  <div className="text-[9px] text-gray-500 truncate">{q.shortName || q.symbol}</div>
                </div>
                <div className="flex flex-col items-end shrink-0">
                   <div className="text-[10px] font-mono text-gray-300">{q.regularMarketPrice?.toFixed(2)}</div>
                   <div className={clsx("font-mono text-[9px] font-medium", isUp ? "text-emerald-400" : "text-rose-500")}>
                     {isUp ? "+" : ""}{q.regularMarketChangePercent?.toFixed(2)}%
                   </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Center Column - Chart */}
      <div className="flex-1 flex flex-col min-w-0 md:border-r border-gray-800 bg-[#09090b] overflow-y-auto overflow-x-hidden relative">
        <div className="p-4 border-b border-gray-800 flex flex-wrap items-end gap-3 bg-[#16161a]/30">
          <div>
            <div className="flex items-center gap-2 mb-1">
               <span className="text-xl font-bold text-white">{activeSymbol}</span>
               <span className="text-[10px] font-medium px-1.5 py-0.5 bg-indigo-500/10 text-indigo-400 rounded uppercase border border-indigo-500/20">{selectedQuote?.exchange || "MARKET"}</span>
            </div>
            <div className="text-[11px] text-gray-500 truncate max-w-[200px]">{selectedQuote?.shortName || activeSymbol}</div>
          </div>
          
          <div className="ml-auto flex items-end gap-3">
             <div className="flex bg-[#09090b] rounded-lg p-0.5 border border-gray-800 mr-4">
                <button 
                  onClick={() => setViewMode("Chart")}
                  className={clsx("px-3 py-1 text-[11px] font-medium rounded-md transition-colors", viewMode === "Chart" ? "bg-gray-800 text-white" : "text-gray-500 hover:text-gray-300")}
                >
                  Technical Chart
                </button>
                <button 
                  onClick={() => setViewMode("Deep Analysis")}
                  className={clsx("px-3 py-1 text-[11px] font-medium rounded-md transition-colors", viewMode === "Deep Analysis" ? "bg-indigo-500/20 text-indigo-400" : "text-gray-500 hover:text-gray-300")}
                >
                  Deep Analysis
                </button>
             </div>
             <span className="text-2xl font-mono font-bold text-white leading-none">
               {selectedQuote?.regularMarketPrice?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || "..."}
             </span>
             {selectedQuote && (
               <div className={clsx("font-mono text-sm leading-none pb-0.5", (selectedQuote.regularMarketChange || 0) >= 0 ? "text-emerald-400" : "text-rose-500")}>
                 {(selectedQuote.regularMarketChange || 0) >= 0 ? "▲" : "▼"} {Math.abs(selectedQuote.regularMarketChange || 0).toFixed(2)} ({Math.abs(selectedQuote.regularMarketChangePercent || 0).toFixed(2)}%)
               </div>
             )}
          </div>
        </div>

        {viewMode === "Chart" ? (
          <>
            <div className="flex gap-2 px-4 py-2 border-b border-gray-800 bg-[#16161a]/20">
              {["1m", "5m", "15m", "1H", "1D", "1W", "1M"].map(tf => (
                <button 
                   key={tf}
                   className={clsx(
                     "text-[10px] px-2.5 py-1 rounded transition-colors font-medium",
                     tf === "1D" ? "bg-gray-800 text-white" : "text-gray-500 hover:text-gray-300"
                   )}
                >{tf}</button>
              ))}
              <button className="ml-auto text-[10px] font-medium text-gray-400 flex items-center gap-1.5 hover:text-white px-2 py-1 rounded bg-gray-800/50">
                <Settings className="w-3.5 h-3.5" /> Indicators
              </button>
            </div>

            {/* Chart Area */}
            <div className="flex-1 relative bg-[#09090b] min-h-[300px]">
              <StockChart symbol={activeSymbol} />
            </div>

            {/* Technical Summary Bar */}
            <div className="border-t border-gray-800 bg-[#16161a] mt-auto">
               {selectedQuote && (
                 <div className="flex flex-wrap text-[10px] items-center divide-x divide-gray-800">
                    <div className="px-4 py-3 flex flex-col gap-0.5 min-w-[120px]">
                      <span className="text-gray-500 uppercase tracking-widest font-semibold">Prev Close</span>
                      <span className="font-mono text-gray-200">{selectedQuote.regularMarketPreviousClose?.toFixed(2) || "N/A"}</span>
                    </div>
                    <div className="px-4 py-3 flex flex-col gap-0.5 min-w-[120px]">
                      <span className="text-gray-500 uppercase tracking-widest font-semibold">Open</span>
                      <span className="font-mono text-gray-200">{selectedQuote.regularMarketOpen?.toFixed(2) || "N/A"}</span>
                    </div>
                    <div className="px-4 py-3 flex flex-col gap-0.5 min-w-[120px]">
                      <span className="text-gray-500 uppercase tracking-widest font-semibold">Volume</span>
                      <span className="font-mono text-gray-200">{selectedQuote.regularMarketVolume ? (selectedQuote.regularMarketVolume / 1000000).toFixed(2) + 'M' : 'N/A'}</span>
                    </div>
                    {selectedQuote.marketCap && (
                      <div className="px-4 py-3 flex flex-col gap-0.5 min-w-[120px]">
                        <span className="text-gray-500 uppercase tracking-widest font-semibold">Market Cap</span>
                        <span className="font-mono text-gray-200">{(selectedQuote.marketCap / 1000000000).toFixed(2)}B</span>
                      </div>
                    )}
                    {selectedQuote.trailingPE && (
                      <div className="px-4 py-3 flex flex-col gap-0.5 min-w-[120px]">
                        <span className="text-gray-500 uppercase tracking-widest font-semibold">P/E Ratio</span>
                        <span className="font-mono text-gray-200">{selectedQuote.trailingPE.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="px-4 py-3 flex flex-col gap-0.5 min-w-[120px]">
                      <span className="text-gray-500 uppercase tracking-widest font-semibold">52W Range</span>
                      <span className="font-mono text-gray-200">{selectedQuote.fiftyTwoWeekLow?.toFixed(2) || "-"} - {selectedQuote.fiftyTwoWeekHigh?.toFixed(2) || "-"}</span>
                    </div>
                    <div className="px-4 py-3 flex flex-col gap-0.5 min-w-[120px]">
                      <span className="text-gray-500 uppercase tracking-widest font-semibold">50d / 200d MA</span>
                      <span className="font-mono text-gray-200">
                        <span className={(selectedQuote.regularMarketPrice || 0) > (selectedQuote.fiftyDayAverage || 0) ? "text-emerald-400" : "text-rose-400"}>
                          {selectedQuote.fiftyDayAverage?.toFixed(2) || "-"}
                        </span>
                        {" / "}
                        <span className={(selectedQuote.regularMarketPrice || 0) > (selectedQuote.twoHundredDayAverage || 0) ? "text-emerald-400" : "text-rose-400"}>
                          {selectedQuote.twoHundredDayAverage?.toFixed(2) || "-"}
                        </span>
                      </span>
                    </div>
                 </div>
               )}
            </div>
          </>
        ) : (
          <div className="flex-1 relative">
             <DeepAnalytics symbol={activeSymbol} />
          </div>
        )}
      </div>

      {/* Right Column - Calendar & Screener */}
      <div className="w-full lg:w-[260px] flex flex-col shrink-0 bg-[#09090b] h-[400px] lg:h-auto border-t lg:border-t-0 border-gray-800">
        {/* Calendar */}
        <div className="p-3 py-3 border-b border-gray-800 flex justify-between items-center bg-[#16161a]">
          <span className="text-[11px] font-bold text-white uppercase tracking-widest">Economic Calendar</span>
          <span className="text-[10px] text-gray-500">Upcoming</span>
        </div>
        <div className="flex-none bg-[#09090b] overflow-y-auto">
          {events.length > 0 ? (
            events.map((event, i) => (
              <CalendarItemWidget key={i} event={event} />
            ))
          ) : (
            <div className="px-4 py-8 text-center text-xs text-gray-500">
               No upcoming events
               <br/>
               <span className="text-[10px] animate-pulse">Fetching latest...</span>
            </div>
          )}
        </div>

        {/* Screener */}
        <div className="flex border-b border-t border-gray-800 mt-2 bg-[#16161a]">
          {(["Gainers", "Losers", "Active", "News"] as ScreenerTab[]).map(t => (
             <button 
               key={t}
               onClick={() => setScreenerTab(t)}
               className={clsx(
                 "flex-1 py-2 text-[9px] font-bold border-b-2 transition-colors uppercase tracking-widest leading-none",
                 screenerTab === t ? "border-indigo-500 text-white" : "border-transparent text-gray-500 hover:text-gray-300"
               )}
             >{t}</button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto hide-scrollbar py-1">
          {screenerTab === "News" ? (
             <NewsFeed symbol={activeSymbol} />
          ) : (
             sortedScreener.map(q => {
               const isUp = (q.regularMarketChange || 0) >= 0;
               return (
                  <div 
                    key={q.symbol} 
                    onClick={() => setSelectedSymbol(q.symbol)}
                    className="flex justify-between items-center px-4 py-2 border-b border-gray-800/30 cursor-pointer hover:bg-gray-800/40"
                  >
                    <div className="flex flex-col mr-2 overflow-hidden">
                      <div className="text-[11px] font-bold text-gray-200">{q.symbol.replace("=X", "").replace("-USD", "")}</div>
                      <div className="text-[9px] text-gray-500 truncate">{q.shortName || q.symbol}</div>
                    </div>
                    <span className={clsx("font-mono text-[11px] font-bold", isUp ? "text-emerald-400" : "text-rose-500")}>
                      {isUp ? "+" : ""}{q.regularMarketChangePercent?.toFixed(2)}%
                    </span>
                  </div>
               )
             })
          )}
        </div>
      </div>
    </div>
  );
}
