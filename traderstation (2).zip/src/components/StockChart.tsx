import { useEffect, useRef, useState } from "react";
import { createChart, ColorType, IChartApi, ISeriesApi, Time, CandlestickSeries } from "lightweight-charts";
import { HistoricalData } from "../types";

interface StockChartProps {
  symbol: string;
}

export function StockChart({ symbol }: StockChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    let interval: NodeJS.Timeout;

    const initChart = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/stocks/history?symbol=${encodeURIComponent(symbol)}`);
        if (!res.ok) throw new Error("Failed to fetch history");
        const json = await res.json();
        
        if (!mounted || !chartContainerRef.current) return;

        // format data for lightweight-charts
        const chartData = json
          .map((d: any) => {
             // Convert date strings to unix timestamp (seconds part only) for Lightweight Charts
             // Some dates might be intraday or daily, lightweight charts uses timestamp for unique times
             const t = Math.floor(new Date(d.date).getTime() / 1000) as Time;
             return {
                time: t,
                open: d.open,
                high: d.high,
                low: d.low,
                close: d.close,
                volume: d.volume,
             };
          })
          .sort((a: any, b: any) => (a.time as number) - (b.time as number))
          // deduplicate same time entries
          .filter((v: any, i: number, a: any[]) => i === 0 || v.time !== a[i-1].time);

        const chart = createChart(chartContainerRef.current, {
          layout: {
            background: { type: ColorType.Solid, color: "transparent" },
            textColor: "#9ca3af",
          },
          grid: {
             vertLines: { color: "#2a2a30", style: 4 }, // 4 is Dotted
             horzLines: { color: "#2a2a30", style: 4 },
          },
          timeScale: {
             borderColor: "#2a2a30",
             timeVisible: true,
             rightOffset: 10,
          },
          rightPriceScale: {
             borderColor: "#2a2a30",
             autoScale: true,
          },
          crosshair: {
            mode: 0, // CrosshairMode.Normal - acts like tradingview
            vertLine: {
              width: 1,
              color: '#52525b',
              style: 3,
              labelBackgroundColor: '#27272a',
            },
            horzLine: {
              width: 1,
              color: '#52525b',
              style: 3,
              labelBackgroundColor: '#27272a',
            },
          },
          width: chartContainerRef.current.clientWidth,
          height: chartContainerRef.current.clientHeight,
        });

        const candlestickSeries = chart.addSeries(CandlestickSeries, {
          upColor: '#34d399',
          downColor: '#f43f5e',
          borderVisible: false,
          wickUpColor: '#34d399',
          wickDownColor: '#f43f5e',
          priceFormat: {
            type: 'price',
            precision: 4,
            minMove: 0.0001,
          },
        });

        const volumeSeries = chart.addHistogramSeries({
          color: '#26a69a',
          priceFormat: {
            type: 'volume',
          },
          priceScaleId: '', // set as an overlay by setting a blank priceScaleId
        });
        
        // Scale the volume down to keep it at the bottom
        volumeSeries.priceScale().applyOptions({
          scaleMargins: {
            top: 0.8, // highest point of the series will be at 80% boundary
            bottom: 0,
          },
        });

        const volumeData = chartData.map((d: any) => ({
           time: d.time,
           value: d.volume || Math.random() * 1000000, 
           color: d.close >= d.open ? 'rgba(52, 211, 153, 0.4)' : 'rgba(244, 63, 94, 0.4)'
        }));

        // MA calculations
        const calculateSMA = (data: any[], period: number) => {
          const result = [];
          for (let i = 0; i < data.length; i++) {
             if (i < period - 1) continue;
             let sum = 0;
             for (let j = 0; j < period; j++) {
                sum += data[i - j].close;
             }
             result.push({ time: data[i].time, value: sum / period });
          }
           return result;
        };

        const ma50Data = calculateSMA(chartData, 50);
        const ma200Data = calculateSMA(chartData, 200);

        const ma50Series = chart.addLineSeries({
            color: '#3b82f6', // blue
            lineWidth: 2,
            crosshairMarkerVisible: false,
            priceLineVisible: false,
            lastValueVisible: false,
        });

        const ma200Series = chart.addLineSeries({
            color: '#f59e0b', // orange
            lineWidth: 2,
            crosshairMarkerVisible: false,
            priceLineVisible: false,
            lastValueVisible: false,
        });

        candlestickSeries.setData(chartData);
        volumeSeries.setData(volumeData);
        if (ma50Data.length > 0) ma50Series.setData(ma50Data);
        if (ma200Data.length > 0) ma200Series.setData(ma200Data);
        chartRef.current = chart;
        seriesRef.current = candlestickSeries;

        chart.timeScale().fitContent();

        // Keep track of the last candle to update it
        let lastCandle = chartData.length > 0 ? { ...chartData[chartData.length - 1] } : null;

        // set up live pricing poll
        interval = setInterval(async () => {
           try {
             const quoteRes = await fetch(`/api/stocks/quote?symbol=${encodeURIComponent(symbol)}`);
             if (!quoteRes.ok) return;
             const quote = await quoteRes.json();
             
             if (quote && quote.regularMarketPrice && seriesRef.current && lastCandle) {
               const closePrice = quote.regularMarketPrice;
               
               // Using quote's daily highs/lows and open if available. Historical API might give current date.
               // We just update the last candle with live price. 
               // In a true live app this would create a new candle if day rolls over, but updating last is fine for demo.
               const dayOpen = quote.regularMarketOpen || lastCandle.open;
               const dayHigh = quote.regularMarketDayHigh || Math.max(lastCandle.high, closePrice);
               const dayLow = quote.regularMarketDayLow || Math.min(lastCandle.low, closePrice);
               
               const updatedCandle = {
                  time: lastCandle.time,
                  open: dayOpen,
                  high: Math.max(dayHigh, closePrice),
                  low: Math.min(dayLow, closePrice),
                  close: closePrice
               };
               
               lastCandle = updatedCandle;
               seriesRef.current.update(updatedCandle);
             }
           } catch (e) {
             console.warn("Live update failed", e);
           }
        }, 5000); // Poll every 5 seconds for live update

        setLoading(false);
      } catch (err) {
        console.warn(err);
        if (mounted) setLoading(false);
      }
    };

    initChart();

    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current) {
        chartRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth,
          height: chartContainerRef.current.clientHeight,
        });
      }
    };

    window.addEventListener("resize", handleResize);

    return () => {
      mounted = false;
      window.removeEventListener("resize", handleResize);
      if (interval) clearInterval(interval);
      if (chartRef.current) {
        chartRef.current.remove();
        chartRef.current = null;
      }
    };
  }, [symbol]);

  return (
    <div className="w-full h-full relative group">
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center text-gray-500 animate-pulse bg-transparent z-10">
          Loading chart data...
        </div>
      )}
      <div ref={chartContainerRef} className="w-full h-full absolute inset-0" />
    </div>
  );
}
