import { useState, useEffect } from "react";
import { NewsItem, QuoteData } from "../types";
import { Search } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";
import { clsx } from "clsx";

function getMockFinancials(symbol: string) {
  const hash = symbol.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return [
    { name: 'Income', value: (hash * 123) % 200 + 100 },
    { name: 'Profit BT', value: (hash * 45) % 50 + 20 },
    { name: 'Net Profit', value: (hash * 30) % 40 + 10 },
  ];
}

function getMockShareholding(symbol: string) {
    const hash = symbol.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const promoter = 30 + (hash % 40);
    const publicShare = 100 - promoter;
    return [
       { name: 'Promoter & Promoter Group', value: promoter, fill: '#34d399' },
       { name: 'Public', value: publicShare, fill: '#facc15' }
    ];
}

function getMockPeers(symbol: string, currentPrice: number) {
    return [
       { symbol: "TCS", ltp: currentPrice * 1.1, chng: -1.37, volume: 99.04, val: 143.69 },
       { symbol: "INFY", ltp: currentPrice * 0.8, chng: 2.12, volume: 117.82, val: 357.60 },
       { symbol: "HDFCBANK", ltp: currentPrice * 0.4, chng: -2.27, volume: 77.20, val: 300.92 },
    ]
}

const CandlestickShape = (props: any) => {
  const { x, y, width, height, payload } = props;
  const value = props.value || payload.bodyData;
  if (!value || !Array.isArray(value)) return null;
  const [minBody, maxBody] = value; 
  const { open, close, high, low } = payload;
  const isUp = close >= open;
  const color = isUp ? '#34d399' : '#fb7185';
  
  const bodyHeight = Math.max(height, 2);
  const valueRange = maxBody - minBody;
  
  let yTopWick = y;
  let yBottomWick = y + bodyHeight;

  if (valueRange > 0) {
    const pixelPerValue = bodyHeight / valueRange;
    yTopWick = y - (high - maxBody) * pixelPerValue;
    yBottomWick = y + bodyHeight + (minBody - low) * pixelPerValue;
  }

  const centerX = x + width / 2;

  return (
    <g>
      <line x1={centerX} y1={yTopWick} x2={centerX} y2={yBottomWick} stroke={color} strokeWidth={1} />
      <rect x={x} y={y} width={width} height={bodyHeight} fill={color} />
      {bodyHeight <= 2 && (
        <line x1={x - width/2} y1={y} x2={x + width * 1.5} y2={y} stroke={color} strokeWidth={2} />
      )}
    </g>
  );
};


const CustomCandlestickTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const isUp = data.close >= data.open;
    return (
      <div className="bg-[#18181b] border border-[#27272a] rounded-lg p-3 shadow-lg">
        <p className="text-gray-400 text-[10px] uppercase tracking-widest mb-2">{label}</p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs font-mono">
           <span className="text-gray-500">Open</span>
           <span className="text-white text-right">{data.open.toFixed(2)}</span>
           <span className="text-gray-500">High</span>
           <span className="text-white text-right">{data.high.toFixed(2)}</span>
           <span className="text-gray-500">Low</span>
           <span className="text-white text-right">{data.low.toFixed(2)}</span>
           <span className="text-gray-500">Close</span>
           <span className={clsx("text-right font-bold", isUp ? "text-emerald-400" : "text-rose-400")}>{data.close.toFixed(2)}</span>
        </div>
      </div>
    );
  }
  return null;
};

export function NewsVisualizer() {
  const [query, setQuery] = useState("");
  const [activeSymbol, setActiveSymbol] = useState("SPY");
  const [news, setNews] = useState<NewsItem[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [quote, setQuote] = useState<QuoteData | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchData = async (symbol: string) => {
    setLoading(true);
    try {
      const [newsRes, histRes, quoteRes] = await Promise.all([
        fetch(`/api/news?symbol=${symbol}`).then(res => res.json()),
        fetch(`/api/stocks/history?symbol=${symbol}`).then(res => res.json()),
        fetch(`/api/stocks/quote?symbol=${symbol}`).then(res => res.json()),
      ]);

      if (Array.isArray(newsRes)) setNews(newsRes);
      
      if (Array.isArray(histRes)) {
        // Format history for recharts
        const formatted = histRes.map(item => ({
          ...item,
          dateFormatted: new Date(item.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
          bodyData: [Math.min(item.open, item.close), Math.max(item.open, item.close)]
        }));
        setHistory(formatted);
      } else {
        setHistory([]);
      }

      if (quoteRes && !quoteRes.error) {
        setQuote(quoteRes);
      } else {
        setQuote(null);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(activeSymbol);
  }, [activeSymbol]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    // Check if it's likely a symbol or need search
    setLoading(true);
    try {
      const res = await fetch(`/api/search?q=${query}`);
      const data = await res.json();
      if (data && data.length > 0) {
        setActiveSymbol(data[0].symbol);
      } else {
        // Fallback, just try the query directly
        setActiveSymbol(query.toUpperCase());
      }
    } catch (e) {
      console.error(e);
    }
  };

  const isUp = quote && (quote.regularMarketChange || 0) >= 0;

  return (
    <div className="p-6 max-w-6xl mx-auto w-full flex flex-col h-full gap-6">
      
      {/* Header and Search */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white uppercase tracking-widest leading-none mb-1">Market News & Data</h1>
          <p className="text-[12px] text-gray-500 font-mono">Visualizing impact for {activeSymbol}</p>
        </div>

        <form onSubmit={handleSearch} className="relative w-full md:w-80">
          <input 
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search stock or news (e.g., TSLA, AI...)"
            className="w-full bg-[#16161a] border border-gray-800 rounded-full py-2 pl-10 pr-4 text-sm text-gray-200 placeholder:text-gray-600 focus:outline-none focus:border-indigo-500/50"
          />
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
        </form>
      </div>

      {loading ? (
        <div className="flex-1 flex items-center justify-center min-h-[300px]">
          <span className="text-gray-500 text-sm font-mono animate-pulse">Loading visualizations...</span>
        </div>
      ) : (
        <div className="flex flex-col lg:flex-row gap-6 w-full items-stretch">
          
          {/* Main Visual Data Column */}
          <div className="flex-1 flex flex-col gap-6">
            
            {/* Context Card */}
            {quote && (
              <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5 flex flex-col md:flex-row justify-between items-center gap-4 shrink-0">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{quote.exchange} / {quote.quoteType}</span>
                  <span className="text-2xl font-bold text-white">{quote.shortName || quote.symbol} <span className="text-gray-600 text-base font-medium">{quote.symbol}</span></span>
                </div>
                <div className="flex items-center gap-4 text-right">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Market Price</span>
                    <span className="text-2xl font-mono text-white">{quote.regularMarketPrice?.toFixed(2)}</span>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Change</span>
                    <span className={clsx("text-lg font-mono font-bold flex items-center", isUp ? "text-emerald-400" : "text-rose-400")}>
                      {isUp ? "▲" : "▼"} {Math.abs(quote.regularMarketChange || 0).toFixed(2)} ({quote.regularMarketChangePercent?.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Chart Column */}
            <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5 min-h-[300px] flex flex-col">
              <h3 className="text-[11px] text-gray-500 font-bold uppercase tracking-widest mb-4">3 Month Price Trend & Impact</h3>
              <div className="flex-1 w-full min-h-[250px]">
                {history.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={history}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                      <XAxis dataKey="dateFormatted" stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} minTickGap={30} />
                      <YAxis 
                        domain={['auto', 'auto']} 
                        stroke="#52525b" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false} 
                        tickFormatter={(v) => v.toFixed(0)}
                        width={40}
                      />
                      <Tooltip 
                        content={<CustomCandlestickTooltip />}
                        cursor={{fill: '#27272a', opacity: 0.4}}
                      />
                      <Bar 
                        dataKey="bodyData" 
                        shape={<CandlestickShape />} 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-gray-500 text-sm">
                    No historical data available for visualization.
                  </div>
                )}
              </div>
            </div>

            {/* Visual Analytics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
              {/* Shareholding Pie */}
              <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5 flex flex-col">
                <h3 className="text-[11px] text-gray-500 font-bold uppercase tracking-widest mb-4">Shareholding Pattern</h3>
                <div className="flex-1 w-full min-h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={getMockShareholding(activeSymbol)}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={70}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {getMockShareholding(activeSymbol).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px' }}
                        itemStyle={{ color: '#e4e4e7', fontSize: '12px', fontFamily: 'sans-serif' }}
                      />
                      <Legend 
                         verticalAlign="bottom" 
                         height={36} 
                         iconType="circle" 
                         wrapperStyle={{ fontSize: '10px', color: '#a1a1aa' }} 
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Financial Results Bar */}
              <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5 flex flex-col">
                <h3 className="text-[11px] text-gray-500 font-bold uppercase tracking-widest mb-4">Financial Result (Cr.)</h3>
                 <div className="flex-1 w-full min-h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={getMockFinancials(activeSymbol)} layout="vertical" margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" horizontal={false} />
                      <XAxis type="number" stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} hide />
                      <YAxis dataKey="name" type="category" stroke="#e4e4e7" fontSize={10} tickLine={false} axisLine={false} width={65} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px' }}
                        itemStyle={{ color: '#e4e4e7', fontSize: '12px', fontFamily: 'monospace' }}
                        cursor={{fill: '#27272a', opacity: 0.4}}
                      />
                      <Bar dataKey="value" fill="#6366f1" radius={[0, 4, 4, 0]} barSize={20} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Trade Info & Peers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
              {/* Trade Info */}
              <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5 flex flex-col">
                 <h3 className="text-[11px] text-gray-500 font-bold uppercase tracking-widest mb-4">Price Information</h3>
                 <div className="grid grid-cols-2 gap-y-4 gap-x-2">
                    <div>
                      <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-1">52 Week High</div>
                      <div className="text-[15px] font-mono text-white">{quote?.fiftyTwoWeekHigh?.toFixed(2) || "-"}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-1">52 Week Low</div>
                      <div className="text-[15px] font-mono text-white">{quote?.fiftyTwoWeekLow?.toFixed(2) || "-"}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-1">Volume</div>
                      <div className="text-[15px] font-mono text-white">{quote?.regularMarketVolume ? (quote.regularMarketVolume / 1000).toFixed(2) + 'k' : "-"}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-1">Market Cap</div>
                      <div className="text-[15px] font-mono text-white">{quote?.marketCap ? (quote.marketCap / 1e9).toFixed(2) + 'B' : "-"}</div>
                    </div>
                 </div>
              </div>

              {/* Peer Comparison */}
              <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5 flex flex-col">
                 <h3 className="text-[11px] text-gray-500 font-bold uppercase tracking-widest mb-4">Peer Comparison</h3>
                 <div className="w-full overflow-x-auto hide-scrollbar">
                    <table className="w-full text-left whitespace-nowrap">
                       <thead>
                          <tr className="border-b border-gray-800">
                             <th className="pb-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest">Symbol</th>
                             <th className="pb-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest text-right">LTP</th>
                             <th className="pb-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest text-right">% Chg</th>
                          </tr>
                       </thead>
                       <tbody>
                          {getMockPeers(activeSymbol, quote?.regularMarketPrice || 100).map(p => (
                            <tr key={p.symbol} className="border-b border-gray-800/30">
                               <td className="py-2.5 text-[11px] font-bold text-indigo-400">{p.symbol}</td>
                               <td className="py-2.5 text-[11px] font-mono text-white text-right">{p.ltp.toFixed(2)}</td>
                               <td className={clsx("py-2.5 text-[11px] font-mono text-right", p.chng >= 0 ? "text-emerald-400" : "text-rose-400")}>
                                  {p.chng >= 0 ? "+" : ""}{p.chng.toFixed(2)}%
                               </td>
                            </tr>
                          ))}
                       </tbody>
                    </table>
                 </div>
              </div>
            </div>
          </div>

          {/* News Feed Column */}
          <div className="w-full lg:w-[350px] shrink-0 flex flex-col">
            <h3 className="text-[11px] text-gray-500 font-bold uppercase tracking-widest mb-4">Latest Headlines</h3>
            <div className="flex-1 flex flex-col gap-3 overflow-y-auto hide-scrollbar max-h-[800px] pr-2">
              {news.length > 0 ? news.map((item, i) => (
                <a 
                  key={item.uuid || i} 
                  href={item.link} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="block p-4 bg-[#16161a] border border-gray-800 rounded-xl hover:border-gray-600 transition-colors group"
                >
                  <div className="text-[13px] font-medium text-gray-300 group-hover:text-indigo-400 transition-colors mb-2 leading-relaxed">
                    {item.title}
                  </div>
                  <div className="flex justify-between items-center text-[9px] text-gray-500 uppercase tracking-widest mt-3">
                    <span className="bg-[#09090b] px-2 py-1 rounded">{item.publisher}</span>
                    <span>{new Date(item.providerPublishTime).toLocaleDateString(undefined, {month: 'short', day: 'numeric'})}</span>
                  </div>
                </a>
              )) : (
                <div className="p-5 border border-gray-800 border-dashed rounded-xl text-center text-sm text-gray-500">
                  No news found for this query.
                </div>
              )}
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
