import { FormEvent, useEffect, useRef, useState } from "react";
import { Send, Bot, User, X, MessageSquare, Loader2, Maximize2, Minimize2 } from "lucide-react";
import { ChatMessage } from "../types";
import { clsx } from "clsx";
import Markdown from "react-markdown";

export function ChatBox() {
  const [isOpen, setIsOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      role: "model",
      content: "Hello! I am TrendAgent. I can provide real-time market data, explain stock movements, and analyze news (e.g., 'Why is gold falling today?', 'What is happening with NSE?'). How can I help you?",
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMessage.content,
          history: messages.slice(1).map((m) => ({ role: m.role, content: m.content })),
        }),
      });

      if (!response.ok) {
        let errorMsg = "Network response was not ok";
        try {
          const errData = await response.json();
          if (errData.error) errorMsg = errData.error;
        } catch (e) {}
        throw new Error(errorMsg);
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error("Stream not available");
      
      const botMessageId = (Date.now() + 1).toString();
      setMessages((prev) => [
        ...prev,
        { id: botMessageId, role: "model", content: "" }
      ]);
      
      setIsLoading(false); // streaming has started

      const decoder = new TextDecoder();
      let done = false;
      let buffer = "";
      while (!done) {
        const { value, done: readerDone } = await reader.read();
        done = readerDone;
        if (value) {
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n\n");
          buffer = lines.pop() || ""; // The last element is the incomplete chunk (or empty string if ends with \n\n)
          for (const lineBlock of lines) {
            const dataLines = lineBlock.split("\n").filter(line => line.trim().startsWith("data: "));
            for (const line of dataLines) {
              const dataStr = line.replace(/^data: /, "").trim();
              if (dataStr === "[DONE]") { done = true; break; }
              try {
                const data = JSON.parse(dataStr);
                if (data.error) throw new Error(data.error);
                if (data.text) {
                  setMessages((prev) => prev.map(m => m.id === botMessageId ? { ...m, content: m.content + data.text } : m));
                }
              } catch(e) {
                 if (e instanceof Error && e.message !== "Unexpected end of JSON input") {
                   throw e;
                 }
              }
            }
          }
        }
      }
    } catch (error) {
      console.warn(error);
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "model",
          content: "Sorry, I encountered an error. Please try again.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-indigo-600 hover:bg-indigo-500 text-white p-4 rounded-full shadow-2xl transition-all duration-300 flex items-center justify-center group z-50 ring-4 ring-indigo-900/30"
      >
        <MessageSquare className="w-6 h-6 group-hover:scale-110 transition-transform" />
      </button>
    );
  }

  return (
    <div 
      className={clsx(
        "fixed bg-[#16161a] border border-gray-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden transition-all duration-300 z-50",
        isExpanded ? "inset-4 md:inset-10" : "bottom-6 right-4 sm:right-6 w-[calc(100vw-32px)] sm:w-[400px] h-[600px] max-h-[calc(100vh-48px)]"
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-[#09090b]/50 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">TrendAgent</h3>
            <p className="text-xs text-emerald-400 flex items-center gap-1">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Online
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-gray-400">
          <button onClick={() => setIsExpanded(!isExpanded)} className="p-1.5 hover:bg-gray-800 rounded-md transition-colors">
            {isExpanded ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
          <button onClick={() => setIsOpen(false)} className="p-1.5 hover:bg-gray-800 hover:text-rose-400 rounded-md transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={clsx(
              "flex gap-3 max-w-[85%]",
              msg.role === "user" ? "ml-auto flex-row-reverse" : ""
            )}
          >
            <div
              className={clsx(
                "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
                msg.role === "user" ? "bg-gray-800" : "bg-indigo-600"
              )}
            >
              {msg.role === "user" ? (
                <User className="w-5 h-5 text-gray-300" />
              ) : (
                <Bot className="w-5 h-5 text-white" />
              )}
            </div>
            <div
              className={clsx(
                "p-3 rounded-2xl text-sm leading-relaxed",
                msg.role === "user"
                  ? "bg-gray-800/50 text-gray-200 rounded-tr-sm"
                  : "bg-indigo-600/10 border border-indigo-600/20 text-gray-300 rounded-tl-sm shadow-sm"
              )}
            >
              {msg.role === 'model' ? (
                <div className="prose prose-invert prose-p:leading-snug prose-pre:bg-[#09090b] prose-pre:border prose-pre:border-gray-800 max-w-none text-sm">
                   <Markdown>{msg.content}</Markdown>
                </div>
              ) : (
                msg.content
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-3 max-w-[8e5%]">
            <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center shrink-0">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div className="p-4 rounded-2xl rounded-tl-sm bg-indigo-600/10 border border-indigo-600/20 flex items-center gap-2">
               <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
               <span className="text-gray-400 text-sm">Analyzing market data...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-gray-800 bg-[#09090b]">
        <form onSubmit={handleSubmit} className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about stocks, gold, or market news..."
            className="w-full bg-[#16161a] border border-gray-800 rounded-xl py-3 pl-4 pr-12 text-gray-200 placeholder:text-gray-600 focus:outline-none focus:border-indigo-600 transition-shadow"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="absolute right-2 p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full disabled:opacity-50 disabled:hover:bg-indigo-600 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
