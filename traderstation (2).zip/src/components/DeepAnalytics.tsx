import { useState, useEffect } from "react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip as RechartsTooltip, XAxis, YAxis } from "recharts";
import { Loader2, TrendingUp, AlertTriangle, CheckCircle2, Info } from "lucide-react";
import { clsx } from "clsx";

interface DeepAnalyticsProps {
  symbol: string;
}

export function DeepAnalytics({ symbol }: DeepAnalyticsProps) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let mounted = true;
    const fetchDeep = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/ism/stock/deep?symbol=${encodeURIComponent(symbol)}`);
        const json = await res.json();
        if (mounted && json.status === "success") {
          setData(json.summary);
        } else if (mounted) {
          setData(null);
        }
      } catch (err) {
        console.error(err);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    fetchDeep();
    return () => { mounted = false; };
  }, [symbol]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-gray-500">
        <Loader2 className="w-8 h-8 animate-spin mb-4 text-indigo-500" />
        <span className="text-sm font-medium">Analyzing deep fundamentals for {symbol}...</span>
      </div>
    );
  }

  if (!data || Object.keys(data).length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-gray-500">
        <div className="text-sm">Deep fundamentals not available for this symbol.</div>
      </div>
    );
  }

  const incomeStatement = data.incomeStatementHistory?.incomeStatementHistory || [];
  // Sort from oldest to newest for the chart
  const chartData = [...incomeStatement].reverse().map((item: any) => ({
    year: new Date(item.endDate).getFullYear().toString(),
    revenue: item.totalRevenue ? item.totalRevenue / 1e9 : 0,
    netIncome: item.netIncome ? item.netIncome / 1e9 : 0,
    operatingIncome: item.operatingIncome ? item.operatingIncome / 1e9 : 0
  })).filter(item => item.revenue > 0);

  const quote = data.quote || {};
  const stats = data.defaultKeyStatistics || {};
  const fd = data.financialData || {};
  const recs = data.recommendationTrend?.trend?.[0] || {};
  const price = fd.currentPrice || quote.regularMarketPrice || 0;

  const formatB = (val: number) => val ? (val / 1e9).toFixed(2) + 'B' : '-';
  const formatP = (val: number) => val ? (val * 100).toFixed(2) + '%' : '-';

  // Support & Resistance (Pivot Points Standard)
  const high = quote.regularMarketDayHigh || price;
  const low = quote.regularMarketDayLow || price;
  const close = quote.regularMarketPreviousClose || price;
  
  const pivot = (high + low + close) / 3;
  const r1 = (2 * pivot) - low;
  const s1 = (2 * pivot) - high;
  const r2 = pivot + (high - low);
  const s2 = pivot - (high - low);
  const r3 = high + 2 * (pivot - low);
  const s3 = low - 2 * (high - pivot);

  // Moving Average State
  const ma50 = quote.fiftyDayAverage || 0;
  const ma200 = quote.twoHundredDayAverage || 0;
  let trendIndicator = "Neutral";
  if (price > ma50 && price > ma200) trendIndicator = "Strong Bullish";
  else if (price > ma50) trendIndicator = "Mild Bullish";
  else if (price < ma50 && price < ma200) trendIndicator = "Strong Bearish";
  else if (price < ma50) trendIndicator = "Mild Bearish";

  // 52 Week Distance
  const low52 = quote.fiftyTwoWeekLow || 0;
  const high52 = quote.fiftyTwoWeekHigh || 0;
  const range52 = high52 - low52;
  const pos52 = range52 > 0 ? ((price - low52) / range52) * 100 : 50;

  return (
    <div className="flex flex-col h-full bg-[#09090b] text-gray-200 overflow-y-auto hide-scrollbar pb-8 space-y-6">
      
      {/* Overview Metric Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 border-b border-gray-800 bg-[#16161a]">
         <div className="p-4 border-r border-gray-800 flex flex-col justify-center">
            <span className="text-[10px] text-gray-500 font-bold tracking-widest uppercase mb-1">Current Price</span>
            <div className="flex items-end gap-2">
               <span className="text-2xl font-mono text-white">{price.toFixed(2)}</span>
               <span className={clsx("text-sm font-mono mb-0.5", quote.regularMarketChange >= 0 ? "text-emerald-400" : "text-rose-400")}>
                 {quote.regularMarketChange >= 0 ? "+" : ""}{quote.regularMarketChange?.toFixed(2)} ({quote.regularMarketChangePercent?.toFixed(2)}%)
               </span>
            </div>
         </div>
         <div className="p-4 border-r border-gray-800 flex flex-col justify-center">
            <span className="text-[10px] text-gray-500 font-bold tracking-widest uppercase mb-1">Technical Trend</span>
            <div className="flex items-center gap-2">
               <span className={clsx("w-2.5 h-2.5 rounded-full", trendIndicator.includes("Bullish") ? "bg-emerald-500" : trendIndicator.includes("Bearish") ? "bg-rose-500" : "bg-yellow-500")}></span>
               <span className={clsx("text-lg font-bold", trendIndicator.includes("Bullish") ? "text-emerald-400" : "text-rose-400")}>{trendIndicator}</span>
            </div>
         </div>
         <div className="p-4 border-r border-gray-800 flex flex-col justify-center">
            <span className="text-[10px] text-gray-500 font-bold tracking-widest uppercase mb-1">Analyst Consensus</span>
            <div className="text-xl font-bold text-indigo-400">
               {recs.strongBuy || recs.buy ? 'BUY' : (recs.hold ? 'HOLD' : 'SELL')}
            </div>
            <span className="text-[10px] text-gray-500">Based on {recs.strongBuy + recs.buy + recs.hold + recs.sell + recs.strongSell || 0} analysts</span>
         </div>
         <div className="p-4 flex flex-col justify-center">
            <span className="text-[10px] text-gray-500 font-bold tracking-widest uppercase mb-1">Valuation Status</span>
            <div className="text-xl font-bold">
               <span className={fd.currentPrice < fd.targetHighPrice ? "text-emerald-400" : "text-yellow-400"}>
                 {fd.currentPrice < fd.targetHighPrice ? 'Undervalued' : 'Fair / Overvalued'}
               </span>
            </div>
            <span className="text-[10px] text-gray-500">P/B: {stats.priceToBook?.toFixed(2)} | Fwd PE: {stats.forwardPE?.toFixed(2)}</span>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 px-6">
        {/* Technicals Card */}
        <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5">
           <h3 className="text-[11px] font-bold tracking-widest text-gray-400 uppercase mb-4 border-b border-gray-800 pb-2">SMA & EMA Distance</h3>
           <div className="grid grid-cols-2 gap-x-8 gap-y-4">
              <div className="flex justify-between items-center text-[11px]">
                 <span className="text-gray-500">50 Day MA</span>
                 <span className={clsx("font-mono", price > ma50 ? "text-emerald-400" : "text-rose-400")}>{ma50.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-[11px]">
                 <span className="text-gray-500">200 Day MA</span>
                 <span className={clsx("font-mono", price > ma200 ? "text-emerald-400" : "text-rose-400")}>{ma200.toFixed(2)}</span>
              </div>
              <div className="col-span-2 mt-4 space-y-2">
                 <div className="flex justify-between text-[10px] text-gray-400">
                    <span>52W Low ({low52.toFixed(2)})</span>
                    <span>52W High ({high52.toFixed(2)})</span>
                 </div>
                 <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden relative">
                    <div className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-rose-500 via-yellow-500 to-emerald-500 w-full opacity-50"></div>
                    <div 
                      className="absolute top-0 bottom-0 w-2 bg-white rounded-full shadow-[0_0_8px_rgba(255,255,255,0.8)] -ml-1 transition-all duration-500" 
                      style={{ left: `${Math.min(Math.max(pos52, 0), 100)}%` }}
                    ></div>
                 </div>
                 <div className="text-center text-[10px] text-gray-500 mt-1">
                    Currently trading {Math.abs(price - high52).toFixed(2)} below 52-week high
                 </div>
              </div>
           </div>
        </div>

        {/* Pivot Points Card */}
        <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5">
           <h3 className="text-[11px] font-bold tracking-widest text-gray-400 uppercase mb-4 border-b border-gray-800 pb-2 flex justify-between">
              <span>Resistance & Support Pivot</span>
              <span className="text-indigo-400 font-mono text-[13px]">{pivot.toFixed(2)} PIVOT</span>
           </h3>
           <div className="grid grid-cols-2 gap-x-8 gap-y-3">
              <div className="space-y-3">
                <div className="flex justify-between items-center text-[11px]">
                   <span className="text-gray-500">Resistance 3</span>
                   <span className="font-mono text-rose-400/70">{r3.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                   <span className="text-gray-500">Resistance 2</span>
                   <span className="font-mono text-rose-400/90">{r2.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                   <span className="text-gray-500">Resistance 1</span>
                   <span className="font-mono text-rose-400">{r1.toFixed(2)}</span>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center text-[11px]">
                   <span className="text-emerald-400/70 font-mono">{s3.toFixed(2)}</span>
                   <span className="text-gray-500">Support 3</span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                   <span className="text-emerald-400/90 font-mono">{s2.toFixed(2)}</span>
                   <span className="text-gray-500">Support 2</span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                   <span className="text-emerald-400 font-mono">{s1.toFixed(2)}</span>
                   <span className="text-gray-500">Support 1</span>
                </div>
              </div>
           </div>
        </div>
      </div>

      {/* Charts section */}

      <div className="p-6">
         <div className="mb-6 flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-widest text-white border-l-2 border-indigo-500 pl-3">Revenue & Earnings Growth</h2>
            <div className="text-[10px] text-gray-500 flex gap-4">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-indigo-500"></span> Total Revenue (Billion)</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500"></span> Net Income (Billion)</span>
            </div>
         </div>
         
         <div className="h-[280px] w-full bg-[#16161a]/30 rounded-xl p-4 border border-gray-800">
           {chartData.length > 0 ? (
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                 <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                 <XAxis dataKey="year" stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} />
                 <YAxis stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} />
                 <RechartsTooltip 
                    cursor={{fill: '#27272a', opacity: 0.4}}
                    contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', borderRadius: '8px', fontSize: '11px' }}
                    itemStyle={{ color: '#e4e4e7', fontWeight: 600 }}
                 />
                 <Bar dataKey="revenue" name="Revenue (B)" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={32} />
                 <Bar dataKey="netIncome" name="Net Income (B)" fill="#10b981" radius={[4, 4, 0, 0]} barSize={32} />
               </BarChart>
             </ResponsiveContainer>
           ) : (
             <div className="h-full w-full flex items-center justify-center text-xs text-gray-500">No chart data available</div>
           )}
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-6">
        <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5">
           <h3 className="text-[11px] font-bold tracking-widest text-gray-400 uppercase mb-4 border-b border-gray-800 pb-2">Financial Health</h3>
           <div className="space-y-4">
              <div className="flex justify-between items-end">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-500">Current Ratio</span>
                  <span className="text-sm font-mono font-medium">{fd.currentRatio?.toFixed(2) || '-'}</span>
                </div>
                <div className="text-[10px] text-emerald-400 max-w-[140px] text-right">
                  {fd.currentRatio > 1.5 ? "Strong liquidity" : (fd.currentRatio > 1 ? "Adequate liquidity" : "Poor short-term liquidity")}
                </div>
              </div>

              <div className="flex justify-between items-end">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-500">Total Debt / Equity</span>
                  <span className="text-sm font-mono font-medium">{fd.debtToEquity ? fd.debtToEquity.toFixed(2) + '%' : '-'}</span>
                </div>
                <div className="text-[10px] text-emerald-400 max-w-[140px] text-right">
                  {fd.debtToEquity < 50 ? "Low debt risk" : "Highly leveraged"}
                </div>
              </div>
              
              <div className="flex justify-between items-end">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-500">Operating Cash Flow</span>
                  <span className="text-sm font-mono font-medium">{formatB(fd.operatingCashflow)}</span>
                </div>
                <div className="text-[10px] text-emerald-400 max-w-[140px] text-right">
                  {fd.operatingCashflow > 0 ? "Positive cash generator" : "Burning cash"}
                </div>
              </div>
           </div>
        </div>

        <div className="bg-[#16161a] border border-gray-800 rounded-xl p-5">
           <h3 className="text-[11px] font-bold tracking-widest text-gray-400 uppercase mb-4 border-b border-gray-800 pb-2">Growth & Margins</h3>
           <div className="space-y-4">
              <div className="flex justify-between items-end">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-500">Revenue Growth (YoY)</span>
                  <span className="text-sm font-mono font-medium">{formatP(fd.revenueGrowth)}</span>
                </div>
                <div className="text-[10px] text-emerald-400 max-w-[140px] text-right">
                  {fd.revenueGrowth > 0.1 ? "High growth" : (fd.revenueGrowth > 0 ? "Steady growth" : "Declining revenue")}
                </div>
              </div>

              <div className="flex justify-between items-end">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-500">Gross Margins</span>
                  <span className="text-sm font-mono font-medium">{formatP(fd.grossMargins)}</span>
                </div>
                <div className="text-[10px] text-emerald-400 max-w-[140px] text-right">
                  {fd.grossMargins > 0.4 ? "Excellent pricing power" : "Standard margins"}
                </div>
              </div>
              
              <div className="flex justify-between items-end">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-500">EBITDA Margins</span>
                  <span className="text-sm font-mono font-medium">{formatP(fd.ebitdaMargins)}</span>
                </div>
                <div className="text-[10px] text-emerald-400 max-w-[140px] text-right">
                  {fd.ebitdaMargins > 0.15 ? "Strong core profitability" : "Low margin business"}
                </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
