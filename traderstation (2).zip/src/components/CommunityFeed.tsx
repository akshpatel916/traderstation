import { useState, useRef, useEffect } from "react";
import { 
  collection, 
  query, 
  orderBy, 
  onSnapshot, 
  addDoc, 
  serverTimestamp, 
  deleteDoc, 
  doc 
} from "firebase/firestore";
import { db, auth, handleFirestoreError, OperationType } from "../firebase";
import { ImagePlus, MessageCircle, Trash2, X, Send } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export function CommunityFeed() {
  const [posts, setPosts] = useState<any[]>([]);
  const [user, setUser] = useState(auth.currentUser);

  useEffect(() => {
    const unsubAuth = auth.onAuthStateChanged(u => setUser(u));
    const q = query(collection(db, "posts"), orderBy("createdAt", "desc"));
    const unsubPosts = onSnapshot(q, (snap) => {
      setPosts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (error) => handleFirestoreError(error, OperationType.LIST, "posts"));

    return () => {
      unsubAuth();
      unsubPosts();
    };
  }, []);

  return (
    <div className="max-w-2xl mx-auto py-8 px-4 h-full flex flex-col items-center">
      <div className="w-full bg-[#16161a] border border-gray-800 p-4 rounded-xl mb-6">
        {user ? (
          <CreatePostForm user={user} />
        ) : (
           <p className="text-gray-400 text-center text-sm">Please log in to post to the community.</p>
        )}
      </div>

      <div className="w-full space-y-6 pb-20">
        {posts.map(post => (
          <PostCard key={post.id} post={post} user={user} />
        ))}
        {posts.length === 0 && <p className="text-gray-500 text-center py-10">No posts yet. Be the first to share!</p>}
      </div>
    </div>
  );
}

function CreatePostForm({ user }: { user: any }) {
  const [text, setText] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 500000) {
        alert("Image must be smaller than 500KB due to Firestore limits.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!image) { alert("Please attach an image like Instagram!"); return; }
    setLoading(true);
    try {
      await addDoc(collection(db, "posts"), {
        authorId: user.uid,
        authorName: user.displayName || user.email?.split("@")[0] || "User",
        authorPhotoURL: user.photoURL || `https://ui-avatars.com/api/?name=${user.email || "U"}`,
        imageUrl: image,
        text,
        createdAt: serverTimestamp()
      });
      setText("");
      setImage(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "posts");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div className="flex gap-3">
         <img src={user.photoURL || `https://ui-avatars.com/api/?name=${user.email || "U"}`} alt="" className="w-10 h-10 rounded-full" />
         <textarea 
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Write a caption..."
            className="flex-1 bg-transparent border-0 ring-0 focus:ring-0 resize-none text-gray-200 placeholder:text-gray-500 min-h-[60px] text-sm"
         />
      </div>
      {image && (
        <div className="relative rounded-lg overflow-hidden border border-gray-800 group">
          <img src={image} className="w-full max-h-[400px] object-cover" alt="Upload preview" />
          <button type="button" onClick={() => setImage(null)} className="absolute top-2 right-2 p-1.5 bg-black/50 hover:bg-black text-white rounded-full transition-colors opacity-0 group-hover:opacity-100">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
      <div className="flex items-center justify-between pt-2 border-t border-gray-800 border-dashed">
         <button 
           type="button" 
           onClick={() => fileInputRef.current?.click()}
           className="text-indigo-400 hover:text-indigo-300 flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-indigo-500/10 transition-colors text-sm font-medium"
         >
            <ImagePlus className="w-4 h-4" /> Photo
         </button>
         <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleImageUpload} />
         
         <button disabled={loading || !image} type="submit" className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-1.5 rounded-lg font-medium text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            {loading ? "Posting..." : "Share"}
         </button>
      </div>
    </form>
  )
}

function PostCard({ post, user }: { post: any, user: any }) {
  const [comments, setComments] = useState<any[]>([]);
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!showComments) return;
    const q = query(
        collection(db, "comments"), 
        // Need orderBy? We might not have index. Let's just filter client side or do simple query if no index
        // Firestore requires index if we combine clauses. Let's just fetch all and filter to avoid errors if composite index missing, or just query by postId where postId == ... since we only need by postId
    );
    const unsub = onSnapshot(collection(db, "comments"), (rootSnap) => {
        // Simple manual filter for demo
        const filtered = rootSnap.docs
            .map(d => ({ id: d.id, ...d.data() }))
            .filter((c: any) => c.postId === post.id)
            .sort((a: any, b: any) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));
        setComments(filtered);
    }, (error) => handleFirestoreError(error, OperationType.LIST, "comments"));
    return () => unsub();
  }, [showComments, post.id]);

  const handleDelete = async () => {
    if (confirm("Delete this post?")) {
      try { await deleteDoc(doc(db, "posts", post.id)); }
      catch (error) { handleFirestoreError(error, OperationType.DELETE, `posts/${post.id}`); }
    }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    setLoading(true);
    try {
      await addDoc(collection(db, "comments"), {
        postId: post.id,
        authorId: user.uid,
        authorName: user.displayName || user.email?.split("@")[0] || "User",
        authorPhotoURL: user.photoURL || `https://ui-avatars.com/api/?name=${user.email || "U"}`,
        text: commentText,
        createdAt: serverTimestamp()
      });
      setCommentText("");
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "comments");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full bg-[#16161a] border border-gray-800 rounded-xl overflow-hidden">
      <div className="p-4 flex items-center justify-between">
         <div className="flex items-center gap-3">
            <img src={post.authorPhotoURL} alt="" className="w-8 h-8 rounded-full border border-gray-700" />
            <div className="flex flex-col">
               <span className="text-sm font-bold text-white">{post.authorName}</span>
               <span className="text-[10px] text-gray-500">
                  {post.createdAt?.toDate() ? formatDistanceToNow(post.createdAt.toDate(), { addSuffix: true }) : 'Just now'}
               </span>
            </div>
         </div>
         {user?.uid === post.authorId && (
            <button onClick={handleDelete} className="text-gray-500 hover:text-rose-400 p-1 rounded-full transition-colors">
               <Trash2 className="w-4 h-4" />
            </button>
         )}
      </div>

      {post.imageUrl && (
         <img src={post.imageUrl} alt="" className="w-full object-cover max-h-[600px]" />
      )}

      <div className="p-4">
         <div className="flex gap-4 mb-3">
            <button onClick={() => setShowComments(!showComments)} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
               <MessageCircle className="w-6 h-6" />
            </button>
         </div>
         {post.text && (
            <div className="text-sm text-gray-300">
               <span className="font-bold text-white mr-2">{post.authorName}</span>
               {post.text}
            </div>
         )}

         {showComments && (
            <div className="mt-4 pt-4 border-t border-gray-800">
               <div className="space-y-3 mb-4 max-h-[250px] overflow-y-auto hide-scrollbar">
                  {comments.map(c => (
                     <div key={c.id} className="flex gap-2">
                        <span className="text-xs font-bold text-gray-300 whitespace-nowrap">{c.authorName}</span>
                        <span className="text-xs text-gray-400 break-words">{c.text}</span>
                     </div>
                  ))}
               </div>
               {user ? (
                  <form onSubmit={handleComment} className="flex gap-2 items-center relative">
                     <input 
                        type="text" 
                        value={commentText}
                        onChange={e => setCommentText(e.target.value)}
                        placeholder="Add a comment..."
                        className="flex-1 bg-[#09090b] border border-gray-800 rounded-full px-4 py-2 text-sm text-gray-200 placeholder:text-gray-600 focus:outline-none focus:border-indigo-500/50"
                     />
                     <button disabled={loading || !commentText.trim()} type="submit" className="absolute right-2 p-1.5 text-indigo-400 hover:text-indigo-300 disabled:opacity-50">
                        <Send className="w-4 h-4" />
                     </button>
                  </form>
               ) : (
                  <p className="text-xs text-gray-500">Log in to comment.</p>
               )}
            </div>
         )}
      </div>
    </div>
  )
}
