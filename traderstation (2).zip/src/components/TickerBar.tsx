import { useState, useEffect } from "react";
import { QuoteData } from "../types";

const TICKER_SYMBOLS = [
  "^NSEI", "^BSESN", "RELIANCE.NS", "HDFCBANK.NS", "TCS.NS", "INFY.NS", "ICICIBANK.NS", "LT.NS",
  "EURUSD=X", "JPY=X", "GBPUSD=X", "AUDUSD=X", "NZDUSD=X", "EURJPY=X", "GBPJPY=X", "USDCHF=X", "USDCAD=X", "INR=X",
  "GC=F", "CL=F", "^IXIC"
];

export function TickerBar() {
  const [tickerData, setTickerData] = useState<QuoteData[]>([]);

  useEffect(() => {
    let mounted = true;
    const fetchTicker = async () => {
      try {
        const res = await fetch(`/api/stocks/quotes?symbols=${encodeURIComponent(TICKER_SYMBOLS.join(','))}`);
        const results = await res.json();
        if (mounted && Array.isArray(results)) {
          setTickerData(results);
        }
      } catch (e) {
        console.warn(e);
      }
    };
    fetchTicker();
    const interval = setInterval(fetchTicker, 5000); // Poll every 5s for live pricing
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="h-10 bg-[#16161a] border-b border-gray-800 flex items-center overflow-hidden text-xs font-mono whitespace-nowrap z-50 relative pointer-events-none">
      {tickerData.length > 0 ? (
        <div className="flex animate-marquee w-max select-none">
           {[...tickerData, ...tickerData].map((quote, index) => {
             const isUp = (quote.regularMarketChange || 0) >= 0;
             return (
               <div key={`${quote.symbol}-${index}`} className="flex items-center space-x-2 shrink-0 px-6 border-r border-gray-800/50">
                 <span className="text-gray-500 font-bold">{quote.shortName || quote.symbol}</span>
                 <span className={isUp ? "text-emerald-400" : "text-rose-500"}>
                   {quote.regularMarketPrice?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} 
                   {" "}
                   ({isUp ? "+" : ""}{quote.regularMarketChangePercent?.toFixed(2)}%)
                 </span>
               </div>
             );
           })}
        </div>
      ) : (
        <div className="px-4 text-gray-600 animate-pulse">Loading Market Data...</div>
      )}
      <div className="absolute right-0 top-0 h-full w-32 bg-gradient-to-l from-[#16161a] to-transparent pointer-events-none"></div>
    </div>
  );
}
