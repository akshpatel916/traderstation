/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Navbar } from "./components/Navbar";
import { TickerBar } from "./components/TickerBar";
import { Dashboard } from "./components/Dashboard";
import { DataOverview } from "./components/DataOverview";
import { ChatBox } from "./components/ChatBox";
import { SearchOverlay } from "./components/SearchOverlay";
import { CommunityFeed } from "./components/CommunityFeed";
import { NewsVisualizer } from "./components/NewsVisualizer";

export default function App() {
  const [activeView, setActiveView] = useState("Markets");
  const [chartSymbol, setChartSymbol] = useState("AAPL");
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const handleNavigate = (view: string, symbol?: string) => {
    setActiveView(view);
    if (symbol) {
      setChartSymbol(symbol);
      setActiveView("Chart");
    }
  };

  return (
    <div className="h-screen bg-[#09090b] font-sans text-gray-200 selection:bg-indigo-500/30 flex flex-col overflow-hidden">
      <TickerBar />
      <Navbar 
        activeView={activeView === "Chart" ? "Markets" : activeView} 
        onNavigate={handleNavigate} 
        onSearchClick={() => setIsSearchOpen(true)}
      />

      <main className="flex-1 overflow-y-auto overflow-x-hidden bg-[#09090b]">
        {activeView === "Chart" && <Dashboard initialSymbol={chartSymbol} />}
        {activeView === "Community" && <CommunityFeed />}
        {activeView === "News" && <NewsVisualizer />}
        {activeView !== "Chart" && activeView !== "Community" && activeView !== "News" && <DataOverview category={activeView} onOpenChart={(sym) => handleNavigate("Chart", sym)} />}
      </main>

      <ChatBox />
      {isSearchOpen && (
        <SearchOverlay 
          onClose={() => setIsSearchOpen(false)} 
          onSelect={(symbol) => {
            handleNavigate("Chart", symbol);
            setIsSearchOpen(false);
          }} 
        />
      )}
    </div>
  );
}
