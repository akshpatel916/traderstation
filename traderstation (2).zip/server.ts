import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import YahooFinance from "yahoo-finance2";

const yahooFinance = new YahooFinance();

// Initialize Gemini
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API Routes ---

  // Health route
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Trending symbols
  app.get("/api/stocks/trending", async (req, res) => {
    try {
      const trending = await yahooFinance.trendingSymbols("IN");
      res.json(trending);
    } catch (error) {
      console.error("Error fetching trending:", error);
      res.status(500).json({ error: "Failed to fetch trending symbols" });
    }
  });

  // Historical data for chart
  app.get("/api/stocks/fundamentals", async (req, res) => {
    try {
      const symbol = (req.query.symbol as string);
      if (!symbol) return res.status(400).json({ error: "Missing symbol" });
      const result = await yahooFinance.quoteSummary(symbol, {
        modules: ["assetProfile", "financialData", "defaultKeyStatistics", "summaryDetail", "insiderHolders", "institutionOwnership"]
      });
      res.json(result);
    } catch (error) {
      console.error("Error fetching fundamentals:", error);
      res.status(500).json({ error: "Failed to fetch fundamental data" });
    }
  });

  app.get("/api/stocks/history", async (req, res) => {
    try {
      const symbol = (req.query.symbol as string) || "^NSEI"; // Default to Nifty 50
      const period1 = new Date();
      period1.setMonth(period1.getMonth() - 3); // Last 3 months
      
      const queryOptions = { period1 };
      const result = await yahooFinance.chart(symbol, queryOptions);
      if (!result || !result.quotes) {
        return res.status(404).json({ error: "No historical data found", symbol });
      }
      // Transform chart data to format expected by the frontend
      const historyData = result.quotes.map((q: any) => ({
        date: q.date,
        open: q.open,
        high: q.high,
        low: q.low,
        close: q.close,
        volume: q.volume,
        adjClose: q.adjclose
      }));
      res.json(historyData);
    } catch (error: any) {
      if (error?.message?.includes('No data found') || error?.message?.includes('delisted')) {
        return res.status(404).json({ error: "No historical data found", symbol: req.query.symbol });
      }
      console.error("Error fetching historical data:", error);
      res.status(500).json({ error: "Failed to fetch historical data" });
    }
  });

  // Economic Calendar
  app.get("/api/calendar", async (req, res) => {
    try {
      const response = await fetch("https://nfs.faireconomy.media/ff_calendar_thisweek.json");
      if (!response.ok) {
        if (response.status === 429) {
           return res.json([
             { title: "CPI Data (Fallback)", country: "USD", date: new Date(Date.now() + 86400000).toISOString(), impact: "High", forecast: "3.1%", previous: "3.2%" },
             { title: "Retail Sales (Fallback)", country: "USD", date: new Date(Date.now() + 86400000 * 2).toISOString(), impact: "Medium", forecast: "0.5%", previous: "0.2%" },
             { title: "ECB Rate Decision (Fallback)", country: "EUR", date: new Date(Date.now() + 86400000 * 3).toISOString(), impact: "High", forecast: "4.00%", previous: "4.00%" }
           ]);
        }
        throw new Error("Failed to fetch calendar data");
      }
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Error fetching calendar:", error);
      res.status(500).json({ error: "Failed to fetch calendar data" });
    }
  });

  // News data
  app.get("/api/news", async (req, res) => {
    try {
      const symbol = (req.query.symbol as string) || "^NSEI";
      const result = await yahooFinance.search(symbol);
      res.json(result.news || []);
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ error: "Failed to fetch news data" });
    }
  });

  // Quote data (multiple symbols)
  app.get("/api/stocks/quotes", async (req, res) => {
    try {
      const symbolsStr = req.query.symbols as string;
      if (!symbolsStr) return res.json([]);
      const symbols = symbolsStr.split(",");
      const results = await yahooFinance.quote(symbols);
      res.json(results);
    } catch (error: any) {
      if (error?.message?.includes('No data found') || error?.message?.includes('delisted')) {
        return res.json([]);
      }
      console.warn("Error fetching multiple quotes:", error);
      res.status(500).json({ error: "Failed to fetch quotes" });
    }
  });

  // Quote data
  app.get("/api/stocks/quote", async (req, res) => {
    try {
      const symbol = (req.query.symbol as string) || "^NSEI";
      const result = await yahooFinance.quote(symbol);
      if (!result) {
        return res.status(404).json({ error: "Symbol not found", symbol });
      }
      res.json(result);
    } catch (error: any) {
      if (error?.message?.includes('No data found') || error?.message?.includes('delisted')) {
        return res.status(404).json({ error: "Symbol not found", symbol: req.query.symbol });
      }
      console.warn("Error fetching quote:", error);
      res.status(500).json({ error: "Failed to fetch quote data" });
    }
  });

  app.get("/api/ism/stock", async (req, res) => {
    try {
      let symbol = req.query.symbol as string;
      if (!symbol) return res.status(400).json({ status: "error", message: "Please provide a stock symbol using ?symbol=STOCKNAME" });
      
      const resFormat = (req.query.res as string) || "val";

      // Auto suffix with .NS if not provided and not a known global index
      if (!symbol.includes(".") && !symbol.startsWith("^")) {
        symbol += ".NS";
      }

      const quote = await yahooFinance.quote(symbol);
      const metrics = await yahooFinance.quoteSummary(symbol, { modules: ["defaultKeyStatistics", "summaryDetail", "assetProfile"] }).catch(() => ({}));

      if (!quote) {
        return res.status(404).json({
          status: "error",
          message: `No data found for symbol: ${symbol}. Stock may not exist or market is closed.`
        });
      }

      const isBSE = symbol.endsWith(".BO");
      const altSuffix = isBSE ? ".NS" : ".BO";
      const altExchange = isBSE ? "NSE" : "BSE";
      const baseSymbol = symbol.split(".")[0];
      const altTicker = baseSymbol + altSuffix;

      const fd = metrics.summaryDetail || {};
      const stats = metrics.defaultKeyStatistics || {};
      const profile = metrics.assetProfile || {};

      const formatValue = (val: number | undefined, format: string, isVol?: boolean) => {
        if (!val) return val;
        if (format === "num") return val;
        if (isVol) return { value: Number((val / 10000000).toFixed(2)), unit: "Crores Shares" };
        if (val > 10000000) return { value: Number((val / 10000000).toFixed(2)), unit: "Crores INR" };
        if (val > 100000) return { value: Number((val / 100000).toFixed(2)), unit: "Lakh INR" };
        return { value: Number(val.toFixed(2)), unit: "INR" };
      };

      const formatSimple = (val: number | undefined, format: string, unit: string = "") => {
         if (val === undefined) return val;
         if (format === "num") return val;
         return { value: Number(val.toFixed(2)), unit };
      };

      const response = {
        status: "success",
        symbol: baseSymbol,
        exchange: isBSE ? "BSE" : "NSE",
        ticker: symbol,
        response_format: resFormat === "num" ? "numeric_only" : "values_with_units",
        data: {
          company_name: quote.longName || quote.shortName,
          last_price: formatSimple(quote.regularMarketPrice, resFormat, quote.currency),
          change: formatSimple(quote.regularMarketChange, resFormat, quote.currency),
          percent_change: formatSimple(quote.regularMarketChangePercent, resFormat, "%"),
          previous_close: formatSimple(quote.regularMarketPreviousClose, resFormat, quote.currency),
          open: formatSimple(quote.regularMarketOpen, resFormat, quote.currency),
          day_high: formatSimple(quote.regularMarketDayHigh, resFormat, quote.currency),
          day_low: formatSimple(quote.regularMarketDayLow, resFormat, quote.currency),
          year_high: formatSimple(quote.fiftyTwoWeekHigh, resFormat, quote.currency),
          year_low: formatSimple(quote.fiftyTwoWeekLow, resFormat, quote.currency),
          volume: formatValue(quote.regularMarketVolume, resFormat, true),
          market_cap: formatValue(quote.marketCap, resFormat),
          pe_ratio: formatSimple(quote.trailingPE, resFormat, "x"),
          dividend_yield: formatSimple(fd.dividendYield ? fd.dividendYield * 100 : undefined, resFormat, "%"),
          book_value: formatSimple(stats.bookValue, resFormat, quote.currency),
          earnings_per_share: formatSimple(quote.epsTrailingTwelveMonths, resFormat, quote.currency),
          sector: profile.sector || "Unknown",
          industry: profile.industry || "Unknown",
          currency: quote.currency || "INR",
          last_update: new Date().toISOString().split("T")[0],
          timestamp: new Date().toISOString().replace("T", " ").split(".")[0]
        },
        alternate_exchange: {
          exchange: altExchange,
          ticker: altTicker,
          api_url: `/stock?symbol=${altTicker}&res=${resFormat}`
        }
      };

      res.json(response);
    } catch (error) {
      console.error("Error fetching ISM quote:", error);
      res.status(500).json({ status: "error", message: "Failed to fetch stock data" });
    }
  });

  app.get("/api/ism/stock/deep", async (req, res) => {
    try {
      let symbol = req.query.symbol as string;
      if (!symbol) return res.status(400).json({ status: "error", message: "Missing symbol param" });
      
      if (!symbol.includes(".") && !symbol.startsWith("^")) {
        symbol += ".NS";
      }

      const quote = await yahooFinance.quote(symbol).catch(() => null);
      if (!quote) {
        return res.status(404).json({ status: "error", message: "Not found" });
      }

      const summary = await yahooFinance.quoteSummary(symbol, {
        modules: [
          "defaultKeyStatistics", "financialData", 
          "earnings", "recommendationTrend", "incomeStatementHistory"
        ]
      }).catch(() => ({}));

      res.json({
        status: "success",
        symbol,
        quote,
        summary
      });
    } catch (e) {
      console.error(e);
      res.status(500).json({ status: "error", message: "Server error" });
    }
  });

  app.get("/api/ism/stock/list", async (req, res) => {
    try {
      const symbolsStr = req.query.symbols as string;
      if (!symbolsStr) return res.json({ status: "error", message: "Missing symbols parameter" });
      const resFormat = (req.query.res as string) || "val";
      
      const rawSymbols = symbolsStr.split(",");
      const symbols = rawSymbols.map(s => {
         if (!s.includes(".") && !s.startsWith("^")) return s + ".NS";
         return s;
      });

      const quotes = await yahooFinance.quote(symbols);
      
      const formatValue = (val: number | undefined, format: string, isVol?: boolean) => {
        if (!val) return val;
        if (format === "num") return val;
        if (isVol) return { value: Number((val / 10000000).toFixed(2)), unit: "Crores Shares" };
        if (val > 10000000) return { value: Number((val / 10000000).toFixed(2)), unit: "Crores INR" };
        if (val > 100000) return { value: Number((val / 100000).toFixed(2)), unit: "Lakh INR" };
        return { value: Number(val.toFixed(2)), unit: "INR" };
      };

      const formatSimple = (val: number | undefined, format: string, unit: string = "") => {
         if (val === undefined) return val;
         if (format === "num") return val;
         return { value: Number(val.toFixed(2)), unit };
      };

      const stockResults = quotes.map(quote => {
         const isBSE = quote.symbol.endsWith(".BO");
         const baseSymbol = quote.symbol.split(".")[0];
         return {
            symbol: baseSymbol,
            exchange: isBSE ? "BSE" : "NSE",
            ticker: quote.symbol,
            company_name: quote.longName || quote.shortName,
            last_price: formatSimple(quote.regularMarketPrice, resFormat, quote.currency),
            change: formatSimple(quote.regularMarketChange, resFormat, quote.currency),
            percent_change: formatSimple(quote.regularMarketChangePercent, resFormat, "%"),
            previous_close: formatSimple(quote.regularMarketPreviousClose, resFormat, quote.currency),
            open: formatSimple(quote.regularMarketOpen, resFormat, quote.currency),
            day_high: formatSimple(quote.regularMarketDayHigh, resFormat, quote.currency),
            day_low: formatSimple(quote.regularMarketDayLow, resFormat, quote.currency),
            volume: formatValue(quote.regularMarketVolume, resFormat, true),
            market_cap: formatValue(quote.marketCap, resFormat)
         };
      });

      res.json({
        status: "success",
        count: stockResults.length,
        stocks: stockResults
      });
    } catch (error) {
      console.warn("Error fetching multiple ISM quotes:", error);
      res.status(500).json({ status: "error", message: "Failed to fetch stock list" });
    }
  });

  app.get("/api/ism/symbols", (req, res) => {
    // Top 30 NSE symbols for quick reference and caching
    const symbols = [
      "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
      "HINDUNILVR.NS", "SBIN.NS", "BHARTIARTL.NS", "ITC.NS", "KOTAKBANK.NS",
      "LARSEN.NS", "BAJFINANCE.NS", "AXISBANK.NS", "ASIANPAINT.NS", "MARUTI.NS",
      "TITAN.NS", "BAJAJFINSV.NS", "WIPRO.NS", "NESTLEIND.NS", "HCLTECH.NS",
      "M&M.NS", "SUNPHARMA.NS", "ULTRACEMCO.NS", "TATASTEEL.NS", "TECHM.NS",
      "POWERGRID.NS", "INDUSINDBK.NS", "NTPC.NS", "TATACOMM.NS", "ONGC.NS"
    ];
    res.json({
      status: "success",
      total_symbols: symbols.length,
      symbols
    });
  });

  app.get("/api/ism/search", async (req, res) => {
    try {
      const q = req.query.q as string;
      if (!q) return res.json({ status: "error", message: "Missing query parameter" });
      const results = await yahooFinance.search(q);
      res.json({
        status: "success",
        query: q,
        total_results: results.quotes.length,
        results: results.quotes
      });
    } catch (error) {
       res.status(500).json({ error: "Failed to search" });
    }
  });

  app.get("/api/search", async (req, res) => {
    try {
      const q = req.query.q as string;
      if (!q) return res.json([]);
      const results = await yahooFinance.search(q);
      res.json(results.quotes);
    } catch (error) {
      console.error("Error searching:", error);
      res.status(500).json({ error: "Failed to search" });
    }
  });

  // Chat with AI Agent
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      const chatContents = (history || []).map((msg: any) => ({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: msg.content }],
      }));

      chatContents.push({
        role: "user",
        parts: [{ text: message }],
      });

      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      const responseStream = await ai.models.generateContentStream({
        model: "gemini-2.5-flash",
        contents: chatContents,
        config: {
          systemInstruction: "You are an elite, highly knowledgeable stock market AI assistant named TrendAgent. You provide deep, actionable insights into the stock market (especially NSE/India and global markets, gold, forex, etc.). When answering questions, use Google Search grounding to find the latest news, actual reasons for market moves, and insider perspectives. Focus on clear, analytical, and professional responses.",
          tools: [{ googleSearch: {} }],
        },
      });

      for await (const chunk of responseStream) {
        if (chunk.text) {
          res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
        }
      }
      res.write("data: [DONE]\n\n");
      res.end();
    } catch (error: any) {
      console.error("Error in chat:", error);
      res.write(`data: ${JSON.stringify({ error: error.message || "Failed to generate AI response" })}\n\n`);
      res.write("data: [DONE]\n\n");
      res.end();
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Static files in production
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
