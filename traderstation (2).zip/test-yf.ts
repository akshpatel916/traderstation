import yahooFinance from 'yahoo-finance2';
async function test() {
  try {
    const result = await yahooFinance.quoteSummary("RELIANCE.NS", { modules: ["financialData", "earnings", "incomeStatementHistory", "recommendationTrend", "upgradeDowngradeHistory"] });
    console.log(JSON.stringify(Object.keys(result)));
  } catch(e) {
    console.error(e);
  }
}
test();
